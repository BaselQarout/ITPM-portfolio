classdef temp_task_2_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                       matlab.ui.Figure
        GridLayout                     matlab.ui.container.GridLayout
        Panel3                         matlab.ui.container.Panel
        ApplytothewholeimageCheckBox   matlab.ui.control.CheckBox
        NumberofCornersSpinner         matlab.ui.control.Spinner
        NumberofCornersSpinnerLabel    matlab.ui.control.Label
        CornerDetectionLabel           matlab.ui.control.Label
        DetectCornersButton            matlab.ui.control.Button
        MinQualitySpinner              matlab.ui.control.Spinner
        MinQualitySpinnerLabel         matlab.ui.control.Label
        FilterSizeDropDown_2           matlab.ui.control.DropDown
        FilterSizeDropDown_2Label      matlab.ui.control.Label
        CannyEdgeDetectionLabel        matlab.ui.control.Label
        Panel2                         matlab.ui.container.Panel
        SigmaSpinner                   matlab.ui.control.Spinner
        SigmaSpinnerLabel              matlab.ui.control.Label
        HighthreshholdSpinner          matlab.ui.control.Spinner
        HighthreshholdSpinnerLabel     matlab.ui.control.Label
        LowthresholdSpinner            matlab.ui.control.Spinner
        LowthresholdSpinnerLabel       matlab.ui.control.Label
        DetectEdgesButton              matlab.ui.control.Button
        LMFilterBankLabel              matlab.ui.control.Label
        Panel                          matlab.ui.container.Panel
        LMfilterSpinner                matlab.ui.control.Spinner
        LMfilterSpinnerLabel           matlab.ui.control.Label
        applyfilterButton              matlab.ui.control.Button
        ImagepyramidDropDownLabel_2    matlab.ui.control.Label
        templatematchingPanel          matlab.ui.container.Panel
        SelectTemplateFromImageButton  matlab.ui.control.Button
        MatchTechniqueDropDown         matlab.ui.control.DropDown
        MatchthetemplateButton         matlab.ui.control.Button
        UploadtemplateButton           matlab.ui.control.Button
        UIAxes3                        matlab.ui.control.UIAxes
        ImagepyramidDropDown           matlab.ui.control.DropDown
        ImagepyramidDropDownLabel      matlab.ui.control.Label
        pyramidPanel                   matlab.ui.container.Panel
        ApplypyramidButton             matlab.ui.control.Button
        SpatialdomainFilteringLabel    matlab.ui.control.Label
        resetButton                    matlab.ui.control.Button
        uploadphotoButton              matlab.ui.control.Button
        ColorspaceconversionLabel      matlab.ui.control.Label
        HistogramEqualizationButton    matlab.ui.control.Button
        ColorspaceconversionButtonGroup  matlab.ui.container.ButtonGroup
        HSVButton                      matlab.ui.control.RadioButton
        YCbCrButton                    matlab.ui.control.RadioButton
        labButton                      matlab.ui.control.RadioButton
        rgbButton                      matlab.ui.control.RadioButton
        FrequencydomainFilteringLabel  matlab.ui.control.Label
        SpatialFilteringPanel          matlab.ui.container.Panel
        FilterSizeDropDown             matlab.ui.control.DropDown
        FilterSizeDropDownLabel        matlab.ui.control.Label
        Label_2                        matlab.ui.control.Label
        Label                          matlab.ui.control.Label
        SharpeningfilterLabel          matlab.ui.control.Label
        SmoothingfilterLabel           matlab.ui.control.Label
        SharpeningfilterButtonGroup    matlab.ui.container.ButtonGroup
        VerticalSobelButton            matlab.ui.control.RadioButton
        HorizontalSobelButton          matlab.ui.control.RadioButton
        PrewittButton                  matlab.ui.control.RadioButton
        BoostedSobelButton             matlab.ui.control.RadioButton
        SobelButton                    matlab.ui.control.RadioButton
        NoneButton                     matlab.ui.control.RadioButton
        BoostedLaplacian2nddervativeButton  matlab.ui.control.RadioButton
        BoostedLaplacian1stdervativeButton  matlab.ui.control.RadioButton
        Laplacian2nddervativeButton    matlab.ui.control.RadioButton
        Laplacian1stdervativeButton    matlab.ui.control.RadioButton
        ApplyfilterButton              matlab.ui.control.Button
        SmoothingfilterButtonGroup     matlab.ui.container.ButtonGroup
        MedianButton                   matlab.ui.control.RadioButton
        AverageButton                  matlab.ui.control.RadioButton
        BoxButton                      matlab.ui.control.RadioButton
        frequencyfilteringPanel        matlab.ui.container.Panel
        LowpassfilterLabel             matlab.ui.control.Label
        HighpassfilterLabel            matlab.ui.control.Label
        CutoffSpinner                  matlab.ui.control.Spinner
        CutoffLabel                    matlab.ui.control.Label
        HighpassfilterButtonGroup      matlab.ui.container.ButtonGroup
        NoneButton_3                   matlab.ui.control.RadioButton
        GaussianButton_2               matlab.ui.control.RadioButton
        ButterworthButton_2            matlab.ui.control.RadioButton
        IdealButton_2                  matlab.ui.control.RadioButton
        LowpassfilterButtonGroup       matlab.ui.container.ButtonGroup
        NoneButton_2                   matlab.ui.control.RadioButton
        GaussianButton                 matlab.ui.control.RadioButton
        ButterworthButton              matlab.ui.control.RadioButton
        IdealButton                    matlab.ui.control.RadioButton
        ImageIntensityLabel            matlab.ui.control.Label
        ImageintensityPanel            matlab.ui.container.Panel
        High_outSlider                 matlab.ui.control.Slider
        High_outLabel                  matlab.ui.control.Label
        Low_outSlider                  matlab.ui.control.Slider
        Low_outLabel                   matlab.ui.control.Label
        High_inSlider                  matlab.ui.control.Slider
        High_inLabel                   matlab.ui.control.Label
        Low_inSlider                   matlab.ui.control.Slider
        Low_inLabel                    matlab.ui.control.Label
        AdjustBrightnessButton         matlab.ui.control.Button
        UIAxes2                        matlab.ui.control.UIAxes
        UIAxes                         matlab.ui.control.UIAxes
    end

    
    properties (Access = private)
        img % Description
        mod_img;
        cond = false;
        current_space = "rgb";
        template
    end
    
    methods (Access = private)
        
        function F = makeLMfilters(app)
        SUP = 49;
        SCALEX = sqrt(2).^([1 2 3]);
        NORIENT = 6;

        NROTINV = 12;
        NBAR = length(SCALEX) * NORIENT;
        NEDGE = length(SCALEX) * NORIENT;
        NF = NBAR + NEDGE + NROTINV;
        F = zeros(SUP, SUP, NF);
        hsup = (SUP - 1) / 2;
        [x, y] = meshgrid(-hsup:hsup, hsup:-1:-hsup);
        orgpts = [x(:) y(:)]';

        count = 1;
        for scale = 1:length(SCALEX)
            for orient = 0:NORIENT-1
                angle = pi * orient / NORIENT;
                c = cos(angle);
                s = sin(angle);
                rotpts = [c -s; s c] * orgpts;
                F(:, :, count) = makefilter(SCALEX(scale), 0, 1, rotpts, SUP);
                F(:, :, count + NEDGE) = makefilter(SCALEX(scale), 0, 2, rotpts, SUP);
                count = count + 1;
            end
        end

        count = NBAR + NEDGE + 1;
        SCALES = sqrt(2).^([1 2 3 4]);
        for i = 1:length(SCALES)
            F(:, :, count) = normalise(fspecial('gaussian', SUP, SCALES(i)));
            F(:, :, count+1) = normalise(fspecial('log', SUP, SCALES(i)));
            F(:, :, count+2) = normalise(fspecial('log', SUP, 3*SCALES(i)));
            count = count + 3;
        end

        function f = makefilter(scale, phasex, phasey, pts, sup)
            gx = gauss1d(3*scale, 0, pts(1,:), phasex);
            gy = gauss1d(scale, 0, pts(2,:), phasey);
            f = normalise(reshape(gx .* gy, sup, sup));
        end

        function g = gauss1d(sigma, mu, x, ord)
            x = x - mu;
            num = x .* x;
            variance = sigma^2;
            denom = 2 * variance;
            g = exp(-num / denom) / sqrt(pi * denom);
            switch ord
                case 1
                    g = -g .* (x / variance);
                case 2
                    g = g .* ((num - variance) / (variance^2));
            end
        end

        function f = normalise(f)
            f = f - mean(f(:));
            f = f / sum(abs(f(:)));
        end
    end
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            set(app.UIFigure, 'WindowState', 'maximized');
        end

        % Button pushed function: uploadphotoButton
        function uploadphotoButtonPushed(app, event)
           [file,path]=uigetfile({'*.jpg;*.png;*.bmp;*.tif', 'Image Files (*.jpg, *.png, *.bmp, *.tif)'});
           if isequal(file, 0)
                return;
            end
           app.img=imread(fullfile(path,file));
           app.mod_img=app.img;
           
           imshow(app.mod_img,'Parent',app.UIAxes)
           imshow(app.img,'Parent',app.UIAxes2)
           figure(app.UIFigure);
           drawnow;
           set(app.UIFigure, 'WindowState', 'maximized');
        end

        % Button pushed function: AdjustBrightnessButton
        function AdjustBrightnessButtonPushed(app, event)
             if isempty(app.mod_img)
                return;
             end

             app.cond=true;
             low_in = max(0, min(app.Low_inSlider.Value, app.High_inSlider.Value-0.01));
             high_in = min(1, max(app.High_inSlider.Value, app.Low_inSlider.Value+0.01));
            
             % Update sliders to validated values
             app.Low_inSlider.Value = low_in;
             app.High_inSlider.Value = high_in;
            
             % Get output ranges
             low_out = app.Low_outSlider.Value;
             high_out = app.High_outSlider.Value;
            
             % Apply to processed image (not original)
             finalImage = imadjust(app.mod_img, [low_in high_in], [low_out high_out]);
            
             % Display result
             imshow(finalImage, "Parent", app.UIAxes)
        end

        % Button pushed function: HistogramEqualizationButton
        function HistogramEqualizationButtonPushed(app, event)
            if isempty(app.mod_img)
                return;
            end

            app.mod_img=histeq(app.mod_img);

            if(app.cond==true)
                    AdjustBrightnessButtonPushed(app,event);
                    return;
            end
                imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Button pushed function: ApplyfilterButton
        function ApplyfilterButtonPushed(app, event)
            if isempty(app.mod_img)
                return;
            end

            selectedFilter=app.SmoothingfilterButtonGroup.SelectedObject.Text;
            selectedSize=app.FilterSizeDropDown.Value;
            switch selectedFilter
                case "Box"
                    switch selectedSize
                        case "3X3"
                            filter = (1/9).*[1 1 1; 1 1 1; 1 1 1];
                        case "5X5"
                            filter = (1/25).* ones(5,5);
                        case "7X7"
                            filter = (1/49).* ones(7,7);
                        case "9X9"
                            filter = (1/81).*ones(9,9);
                    end
                           
                case "Average"
                    switch selectedSize
                        case "3X3"
                            filter = (1/16).*[1 2 1; 2 4 2; 1 2 1];
                        case "5X5"
                            filter = (1/65).*[1 2 2 2 1; 
                                               1 2 4 2 1;
                                               2 4 8 4 2;
                                               1 2 4 2 1;
                                               1 2 2 2 1];
                        case "7X7"
                            filter = (1/128).*[1 1 1 2 1 1 1; 
                                              1 1 2 4 1 1 2;
                                              1 2 4 8 4 2 1;
                                              2 4 8 16 8 4 2;
                                              1 2 4 8 4 2 1;
                                              1 1 2 4 1 1 2;
                                              1 1 1 2 1 1 1];
                        case "9X9"
                            filter = (1/280).*[1 1 1 1 2 1 1 1 1;
                                                1 1 1 2 4 2 1 1 1; 
                                                1 1 2 4 8 4 2 1 1;
                                                1 2 4 8 16 8 4 2 1;
                                                2 4 8 16 32 16 8 4 2;
                                                1 2 4 8 16 8 4 2 1;
                                                1 1 2 4 8 4 2 1 1;
                                                1 1 1 2 4 2 1 1 1;
                                                1 1 1 1 2 1 1 1 1];
                    end
                case "Median"
                    switch selectedSize
                        case "3X3"
                            if size(app.mod_img, 3) == 3
                                app.mod_img(:,:,1) = medfilt2(app.mod_img(:,:,1), [3 3]);
                                app.mod_img(:,:,2) = medfilt2(app.mod_img(:,:,2), [3 3]);
                                app.mod_img(:,:,3) = medfilt2(app.mod_img(:,:,3), [3 3]);
                            else
                                app.mod_img=medfilt2(app.mod_img, [3 3]);
                            end
                            if(app.cond==true)
                                AdjustBrightnessButtonPushed(app,event);
                                return;
                            end
                            imshow(app.mod_img,"Parent",app.UIAxes)
                            return;
                        case "5X5"
                            if size(app.mod_img, 3) == 3
                                app.mod_img(:,:,1) = medfilt2(app.mod_img(:,:,1), [5 5]);
                                app.mod_img(:,:,2) = medfilt2(app.mod_img(:,:,2), [5 5]);
                                app.mod_img(:,:,3) = medfilt2(app.mod_img(:,:,3), [5 5]);
                            else
                                app.mod_img=medfilt2(app.mod_img, [5 5]);
                            end
                            if(app.cond==true)
                                AdjustBrightnessButtonPushed(app,event);
                                return;
                            end
                            imshow(app.mod_img,"Parent",app.UIAxes)
                            return;
                        case "7X7"
                            if size(app.mod_img, 3) == 3
                                app.mod_img(:,:,1) = medfilt2(app.mod_img(:,:,1), [7 7]);
                                app.mod_img(:,:,2) = medfilt2(app.mod_img(:,:,2), [7 7]);
                                app.mod_img(:,:,3) = medfilt2(app.mod_img(:,:,3), [7 7]);
                            else
                                app.mod_img=medfilt2(app.mod_img, [7 7]);
                            end
                            if(app.cond==true)
                                AdjustBrightnessButtonPushed(app,event);
                                return;
                            end
                            imshow(app.mod_img,"Parent",app.UIAxes)
                            return;
                        case "9X9"
                            if size(app.mod_img, 3) == 3
                                app.mod_img(:,:,1) = medfilt2(app.mod_img(:,:,1), [9 9]);
                                app.mod_img(:,:,2) = medfilt2(app.mod_img(:,:,2), [9 9]);
                                app.mod_img(:,:,3) = medfilt2(app.mod_img(:,:,3), [9 9]);
                            else
                                app.mod_img=medfilt2(app.mod_img, [9 9]);
                            end
                            if(app.cond==true)
                                AdjustBrightnessButtonPushed(app,event);
                                return;
                            end
                            imshow(app.mod_img,"Parent",app.UIAxes)
                            return;
                            
                    end
            end
            app.mod_img=imfilter(app.mod_img,filter);
            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Button pushed function: resetButton
        function resetButtonPushed(app, event)
            app.cond=false;
            app.current_space = "rgb";
            app.Low_inSlider.Value = 0;
            app.Low_outSlider.Value = 0;
            app.High_inSlider.Value = 0;
            app.High_outSlider.Value = 0;
            app.SmoothingfilterButtonGroup.SelectedObject = app.BoxButton;
            app.SharpeningfilterButtonGroup.SelectedObject = app.NoneButton;
            app.FilterSizeDropDown.Value = "3X3";
            app.LowpassfilterButtonGroup.SelectedObject = app.NoneButton_2;
            app.HighpassfilterButtonGroup.SelectedObject = app.NoneButton_3;
            app.CutoffSpinner.Value = 5;
            app.ColorspaceconversionButtonGroup.SelectedObject = app.rgbButton;
            app.LMfilterSpinner.Value = 1;
            app.ImagepyramidDropDown.Value = "reduce";
            app.LowthresholdSpinner.Value = 0.1;
            app.HighthreshholdSpinner.Value = 0.3;
            app.SigmaSpinner.Value = 1;
            app.MinQualitySpinner.Value = 0.01;
            app.FilterSizeDropDown_2.Value = "5X5";
            app.NumberofCornersSpinner.Value = 20;
            app.ApplytothewholeimageCheckBox.Value = 0;

            if isempty(app.mod_img)
                return;
            end
            
            app.mod_img=app.img;

            imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Selection changed function: SharpeningfilterButtonGroup
        function SharpeningfilterButtonGroupSelectionChanged(app, event)
            if isempty(app.mod_img)
                return;
            end
            
            selectedButton = app.SharpeningfilterButtonGroup.SelectedObject.Text;
             A = 3.5;
            
             switch selectedButton

                case "Laplacian 1st dervative"
                    filter = [0 -1 0; -1 4 -1; 0 -1 0];

                case "Laplacian 2nd dervative"
                    filter = [-1 -1 -1; -1 8 -1; -1 -1 -1];

                case "Boosted Laplacian 1st dervative"
                    filter = [0 -1 0; -1 4+A -1; 0 -1 0];

                case "Boosted Laplacian 2nd dervative"
                    filter = [-1 -1 -1; -1 8+A -1; -1 -1 -1];
                
                 case "Vertical Sobel"
                    filter = [-1 0 1; -2 0 2; -1 0 1];

                case "Horizontal Sobel"
                    filter = [-1 -2 -1; 0 0 0; 1 2 1];

                case "Sobel"
                    filter_X = [-1 0 1; -2 0 2; -1 0 1];
                    filter_Y = filter_X';

                    Hor_temp = imfilter(double(app.mod_img),filter_X);
                    Hor_temp = app.mod_img + uint8(Hor_temp);

                    ver_temp = imfilter(double(app.mod_img),filter_Y);
                    ver_temp = app.mod_img + uint8(ver_temp);
                    
                    app.mod_img = Hor_temp + ver_temp;

                    if(app.cond==true)
                        AdjustBrightnessButtonPushed(app,event);
                        return;
                    end
                    imshow(app.mod_img,"Parent",app.UIAxes)
                    return;
        
                case "Boosted Sobel"
                    filter_X = [-1 -2-A -1; 0 0 0; 1 2+A 1];
                    filter_Y = filter_X';

                    Hor_temp = imfilter(double(app.mod_img),filter_X);
                    Hor_temp = app.mod_img + uint8(Hor_temp);

                    ver_temp = imfilter(double(app.mod_img),filter_Y);
                    ver_temp = app.mod_img + uint8(ver_temp);
                    
                    app.mod_img = Hor_temp + ver_temp;

                    if(app.cond==true)
                        AdjustBrightnessButtonPushed(app,event);
                        return;
                    end
                    imshow(app.mod_img,"Parent",app.UIAxes)
                    return;
                
                 case "Prewitt"
                    filter_X = [-1 0 1; -1 0 1; -1 0 1];
                    filter_Y = filter_X';
                    
                    gray_img = rgb2gray(app.mod_img);
                    
                    gray_img = double(gray_img);
                    
                    Gx = imfilter(gray_img, filter_X);
                    Gy = imfilter(gray_img, filter_Y);
                    
                    edge_magnitude = sqrt(Gx.^2 + Gy.^2);
                    
                    edge_magnitude = uint8(255 * mat2gray(edge_magnitude));
                    
                    edge_rgb = cat(3, edge_magnitude, edge_magnitude, edge_magnitude);
                    app.mod_img = edge_rgb;

                    if(app.cond==true)
                        AdjustBrightnessButtonPushed(app,event);
                        return;
                    end
                    imshow(app.mod_img,"Parent",app.UIAxes)
                    return;

                otherwise
                    return;
            end

            filtered=imfilter(app.mod_img,filter);
            app.mod_img = app.mod_img + uint8(filtered);
            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Selection changed function: LowpassfilterButtonGroup
        function LowpassfilterButtonGroupSelectionChanged(app, event)
            if isempty(app.mod_img)
                return;
            end
            
            selectedButton = app.LowpassfilterButtonGroup.SelectedObject.Text;
            
            % Convert to grayscale if RGB
            if size(app.mod_img, 3) == 3
                img_gray = rgb2gray(app.mod_img);
            else
                img_gray = app.mod_img;
            end
            
            % Get frequency domain representation
            FI = fftshift(fft2(double(img_gray)));
            [m,n] = size(img_gray);
            [X,Y] = meshgrid(1:n,1:m);
            X = X-(n+1)/2; 
            Y = Y-(m+1)/2;
            D = sqrt(X.^2+Y.^2);
            
            % Get cutoff frequency from spinner
            D0 = app.CutoffSpinner.Value;

            switch selectedButton
            case "Ideal"
                % Ideal Low-pass Filter
                ILPF = D < D0;
                filtered = ifft2(fftshift(FI.*ILPF));
                
            case "Butterworth"
                % Butterworth Low-pass Filter
                n = 1; % order
                BLPF = 1 ./ (1.0 + (D./D0).^(2*n));
                filtered = ifft2(fftshift(FI.*BLPF));
                
            case "Gaussian"
                % Gaussian Low-pass Filter
                GLPF = exp(-D.^2/(2*D0^2));
                filtered = ifft2(fftshift(FI.*GLPF));
                
            otherwise % "None"
                if(app.cond==true)
                    AdjustBrightnessButtonPushed(app,event);
                    return;
                end
                imshow(app.mod_img,"Parent",app.UIAxes)
                return;
            end
            
            % Convert back to uint8 and handle display
            app.mod_img = uint8(abs(filtered));
            
            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                app.mod_img = cat(3,app.mod_img,app.mod_img,app.mod_img);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
            app.mod_img = cat(3,app.mod_img,app.mod_img,app.mod_img);
        end

        % Selection changed function: HighpassfilterButtonGroup
        function HighpassfilterButtonGroupSelectionChanged(app, event)
            if isempty(app.mod_img)
                return;
            end
            
            selectedButton = app.HighpassfilterButtonGroup.SelectedObject.Text;
            
            % Convert to grayscale if RGB
            if size(app.mod_img, 3) == 3
                img_gray = rgb2gray(app.mod_img);
            else
                img_gray = app.mod_img;
            end
            
            % Get frequency domain representation
            FI = fftshift(fft2(double(img_gray)));
            [m,n] = size(img_gray);
            [X,Y] = meshgrid(1:n,1:m);
            X = X-(n+1)/2; 
            Y = Y-(m+1)/2;
            D = sqrt(X.^2+Y.^2);
            
            % Get cutoff frequency from spinner
            D0 = app.CutoffSpinner.Value;
            
            switch selectedButton

                case "Ideal"
                    IHPF = D > D0;
                    filtered = ifft2(fftshift(FI.*IHPF));
                    
                case "Butterworth"
                    n = 1; % order
                    BHPF = 1 ./ (1.0 + (D0./D).^(2*n));
                    filtered = ifft2(fftshift(FI.*BHPF));
                    
                case "Gaussian"
                    GHPF = 1 - exp(-D.^2/(2*D0^2));
                    filtered = ifft2(fftshift(FI.*GHPF));
                    
                otherwise
                    if(app.cond==true)
                        AdjustBrightnessButtonPushed(app,event);
                        return;
                    end
                    imshow(app.mod_img,"Parent",app.UIAxes)
                    return;
            end
    
            % Convert back to uint8 and handle display
            app.mod_img = uint8(abs(filtered));
            
            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                app.mod_img = cat(3,app.mod_img,app.mod_img,app.mod_img);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
            app.mod_img = cat(3,app.mod_img,app.mod_img,app.mod_img);
        end

        % Selection changed function: ColorspaceconversionButtonGroup
        function ColorspaceconversionButtonGroupSelectionChanged(app, event)
            if isempty(app.mod_img)
                return;
            end
            
            chosen_space = app.ColorspaceconversionButtonGroup.SelectedObject.Text;
            if size(app.mod_img, 3) == 1
                return;
            end
            if ~isa(app.mod_img, 'double')
                app.mod_img = im2double(app.mod_img);
            end
            switch app.current_space
                case 'rgb'
                    tempRGB = app.mod_img; % Already in rgb
                case 'HSV'
                    tempRGB = hsv2rgb(app.mod_img);
                case 'lab'
                    tempRGB = lab2rgb(app.mod_img);
                case 'YCbCr'
                    tempRGB = ycbcr2rgb(app.mod_img);
                otherwise
                    return;
            end
        
            % Convert RGB to the target color space
            switch chosen_space
                case 'rgb'
                    app.mod_img = tempRGB; % No conversion needed
                case 'HSV'
                    app.mod_img = rgb2hsv(tempRGB);
                case 'lab'
                    app.mod_img = rgb2lab(tempRGB);
                case 'YCbCr'
                    app.mod_img = rgb2ycbcr(tempRGB);
                otherwise
                    return;
            end
            
            app.current_space = chosen_space;

            if ~isa(app.mod_img, 'uint8')
                app.mod_img = im2uint8(app.mod_img);
            end

            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Button pushed function: ApplypyramidButton
        function ApplypyramidButtonPushed(app, event)
            if isempty(app.mod_img)
                return;
            end
            selectedPyramid=app.ImagepyramidDropDown.Value;
            switch selectedPyramid
                case "reduce"
                    app.mod_img = impyramid(app.mod_img, "reduce");
                case "expand"
                    app.mod_img = impyramid(app.mod_img, "expand");
            end
            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Button pushed function: MatchthetemplateButton
        function MatchthetemplateButtonPushed(app, event)
            if isempty(app.mod_img) || isempty(app.template)
                return;
            end
        
            % Convert image to grayscale and double
            if size(app.mod_img, 3) == 3
                img_gray = im2double(rgb2gray(app.mod_img));
            else
                img_gray = im2double(app.mod_img);
            end
        
            % Ensure template is grayscale and double
            template_gray = im2double(app.template);  % already converted during upload
        
            selectedMatchTechnique = app.MatchTechniqueDropDown.Value;
        
            switch selectedMatchTechnique
                case "NCC"
                    c = normxcorr2(template_gray, img_gray);
                    [ypeak, xpeak] = find(c == max(c(:)));
                    yoffSet = ypeak - size(template_gray, 1);
                    xoffSet = xpeak - size(template_gray, 2);
                    imshow(app.mod_img, 'Parent', app.UIAxes);
                    drawrectangle(app.UIAxes, 'Position', ...
                        [xoffSet, yoffSet, size(template_gray, 2), size(template_gray, 1)], ...
                        'FaceAlpha', 0, ...
                        'InteractionsAllowed', 'none', ...
                        'Color', 'r');
        
                case "SSD"  % Make sure this matches the dropdown option text exactly
                    [h, w] = size(template_gray);
                
                    % Precompute values
                    template_sq = sum(template_gray(:).^2);
                
                    % Convolve image with template and template mask
                    img_sq = img_gray.^2;
                    sum_img_sq = conv2(img_sq, ones(h, w), 'valid');
                    cross_term = conv2(img_gray, rot90(template_gray, 2), 'valid');
                
                    % SSD = sum((T - I).^2) = sum(T^2) + sum(I^2) - 2*sum(T.*I)
                    R = template_sq + sum_img_sq - 2 * cross_term;
                
                    [~, idx] = min(R(:));
                    [bestY, bestX] = ind2sub(size(R), idx);
                    
                    imshow(app.mod_img, 'Parent', app.UIAxes);
                    drawrectangle(app.UIAxes, ...
                        'Position', [bestX, bestY, w, h], ...
                        'FaceAlpha', 0, ...
                        'Color', 'g', ...
                        'InteractionsAllowed', 'none');
                case 'ZMCC'
                    [h, w] = size(app.template);
                
                    % Zero-mean template
                    template_zm = app.template - mean(app.template(:));
                
                    % Perform correlation
                    c = conv2(img_gray, rot90(template_zm, 2), 'valid');  % Cross-correlation
                
                    % Find peak correlation
                    [ypeak, xpeak] = find(c == max(c(:)));
                
                    imshow(app.mod_img, 'Parent', app.UIAxes);
                    drawrectangle(app.UIAxes, ...
                        'Position', [xpeak, ypeak, w, h], ...
                        'FaceAlpha', 0, ...
                        'Color', 'm', ...
                        'InteractionsAllowed', 'none');

            end
        end

        % Button pushed function: UploadtemplateButton
        function UploadtemplateButtonPushed(app, event)
            [file, path] = uigetfile({'*.jpg;*.png;*.bmp;*.tif', ...
                'Image Files (*.jpg, *.png, *.bmp, *.tif)'});
            
            if isequal(file, 0)
                return;
            end
        
            temp = imread(fullfile(path, file));
            imshow(temp, 'Parent', app.UIAxes3);
        
            if size(temp, 3) == 3
                app.template = im2double(rgb2gray(temp));
            else
                app.template = im2double(temp);
            end
            figure(app.UIFigure);
            drawnow;
            set(app.UIFigure, 'WindowState', 'maximized');
        end

        % Button pushed function: applyfilterButton
        function applyfilterButtonPushed(app, event)
            persistent F;
            filterNumber = app.LMfilterSpinner.Value;
        
            % Generate filter bank once
            if isempty(F)
                F = app.makeLMfilters();
            end
        
            % Ensure grayscale
            tmp = app.mod_img;
            if size(tmp, 3) == 3
                tmp = rgb2gray(tmp);
            end
        
            % Apply selected filter
            app.mod_img = abs(conv2(tmp, F(:,:,filterNumber), 'valid'));  % or 'same'
            app.mod_img = uint8(mat2gray(app.mod_img) * 255);  % Normalize result
        
            % Brightness adjustment (if condition is set)
            if app.cond == true
                AdjustBrightnessButtonPushed(app, event);
                return;
            end
        
            % Show result
            imshow(app.mod_img, "Parent", app.UIAxes);
        end

        % Button pushed function: DetectEdgesButton
        function DetectEdgesButtonPushed(app, event)
            if isempty(app.mod_img)
                return;
            end
        
            % Convert to grayscale if RGB
            if size(app.mod_img, 3) == 3
                img_gray = rgb2gray(app.mod_img);
            else
                img_gray = app.mod_img;
            end
        
            % Get values from sliders
            lowThresh = app.LowthresholdSpinner.Value;
            highThresh = app.HighthreshholdSpinner.Value;
            sigmaVal = app.SigmaSpinner.Value;
        
            % Validate that low < high
            if lowThresh >= highThresh
                uialert(app.UIFigure, ...
                    'Low threshold must be less than high threshold.', ...
                    'Threshold Error');
                return;
            end
        
            % Apply Canny edge detection with custom parameters
            edge_img = uint8(edge(img_gray, 'Canny', [lowThresh highThresh], sigmaVal) * 255);
        
            % Convert to RGB for compatibility with other processing steps
            edge_rgb = cat(3, edge_img, edge_img, edge_img);
        
            % Optional brightness adjustment
            if app.cond
                app.mod_img = edge_rgb;
                AdjustBrightnessButtonPushed(app, event);
                return;
            end
        
            % Display the image
            app.mod_img = edge_rgb;
            imshow(app.mod_img, "Parent", app.UIAxes);
        end

        % Button pushed function: DetectCornersButton
        function DetectCornersButtonPushed(app, event)
            if isempty(app.mod_img)
                return;
            end
        
            % Convert image to grayscale and single
            if size(app.mod_img, 3) == 3
                img_gray = im2single(rgb2gray(app.mod_img));
            else
                img_gray = im2single(app.mod_img);
            end
        
            [imgH, imgW, ~] = size(app.mod_img);
        
            % Get UI values
            minQuality = app.MinQualitySpinner.Value;
            filter_size = app.FilterSizeDropDown.Value;
            numberOfCorners = app.NumberofCornersSpinner.Value;
            fullImage = app.ApplytothewholeimageCheckBox.Value;
        
            % Determine filter size
            switch (filter_size)
                case '3X3'
                    filterSize = 3;
                case '5X5'
                    filterSize = 5;
                case '7X7'
                    filterSize = 7;
                case '9X9'
                    filterSize = 9;
                case '11X11'
                    filterSize = 11;
            end
        
            % Show image
            imshow(app.mod_img, 'Parent', app.UIAxes);
        
            if fullImage
                roi = [];
            else
                % Let user draw ROI interactively
                h = drawrectangle(app.UIAxes, ...
                    'Color', 'r', ...
                    'LineWidth', 1.5, ...
                    'InteractionsAllowed', 'all', ...
                    'FaceAlpha', 0.1);
                uiwait(msgbox("Resize and move the rectangle, then press OK to proceed."));
                roi = round(h.Position);  % [x y w h]
                delete(h);  % Clean up the rectangle
            end
        
            % Detect corners
            if fullImage
                corners = detectHarrisFeatures(img_gray, ...
                    'MinQuality', minQuality, ...
                    'FilterSize', filterSize);
            else
                corners = detectHarrisFeatures(img_gray, ...
                    'MinQuality', minQuality, ...
                    'FilterSize', filterSize, ...
                    'ROI', roi);
            end
        
            % Select strongest corners
            corners = corners.selectStrongest(numberOfCorners);
        
            % Display results
            imshow(app.mod_img, 'Parent', app.UIAxes);
            hold(app.UIAxes, 'on');
            plot(app.UIAxes, corners.Location(:,1), corners.Location(:,2), 'g.');
            if ~fullImage
                rectangle(app.UIAxes, 'Position', roi, 'EdgeColor', 'r', 'LineWidth', 1);
            end
            hold(app.UIAxes, 'off');
        end

        % Button pushed function: SelectTemplateFromImageButton
        function SelectTemplateFromImageButtonPushed(app, event)
            if isempty(app.mod_img)
                return;
            end
        
            % Show image in UIAxes
            imshow(app.mod_img, 'Parent', app.UIAxes);
        
            % Let user draw a resizable rectangle
            h = drawrectangle(app.UIAxes, ...
                'Color', 'b', ...
                'LineWidth', 1.5, ...
                'FaceAlpha', 0.1, ...
                'InteractionsAllowed', 'all');  % Allow move, resize
        
            uiwait(msgbox("Resize and position the rectangle, then press OK in this dialog to confirm."));
        
            % Get rectangle position [x, y, width, height]
            pos = round(h.Position);
            x = pos(1); y = pos(2); w = pos(3); h_ = pos(4);
        
            % Crop from image
            sub_img = imcrop(app.mod_img, [x, y, w-1, h_-1]);
            
            imshow(sub_img, 'Parent', app.UIAxes3);

            % Convert to grayscale and double
            if size(sub_img, 3) == 3
                sub_img = im2double(rgb2gray(sub_img));
            else
                sub_img = im2double(sub_img);
            end
        
            app.template = sub_img;
        
            % Display selected template in UIAxes3
        
            % Optionally delete the rectangle after selection
            delete(h);
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Color = [0.8706 0.8196 0.902];
            app.UIFigure.Position = [100 100 1506 1180];
            app.UIFigure.Name = 'MATLAB App';
            app.UIFigure.Scrollable = 'on';

            % Create GridLayout
            app.GridLayout = uigridlayout(app.UIFigure);
            app.GridLayout.ColumnWidth = {34, 34, 34, 35, 35, 35, 35, 35, 35, 35, 36, 36, 36, 36, 36, 37, 37, 37, 38, 38, 38, 39, 39, 40, 40, 41, 42, 44, 46, 50, '1x'};
            app.GridLayout.RowHeight = {23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 25, 25, 25, 25, 25, 25, 26, 26, 26, 26, 27, 27, 28, 29, 29, 31, 34};
            app.GridLayout.Scrollable = 'on';
            app.GridLayout.BackgroundColor = [1 0.9529 0.9098];

            % Create UIAxes
            app.UIAxes = uiaxes(app.GridLayout);
            title(app.UIAxes, 'Modified image')
            zlabel(app.UIAxes, 'Z')
            app.UIAxes.XTick = [];
            app.UIAxes.YTick = [];
            app.UIAxes.Box = 'on';
            app.UIAxes.Layout.Row = [2 10];
            app.UIAxes.Layout.Column = [20 28];

            % Create UIAxes2
            app.UIAxes2 = uiaxes(app.GridLayout);
            title(app.UIAxes2, 'Original image')
            app.UIAxes2.XTick = [];
            app.UIAxes2.YTick = [];
            app.UIAxes2.Box = 'on';
            app.UIAxes2.Layout.Row = [2 10];
            app.UIAxes2.Layout.Column = [10 18];

            % Create ImageintensityPanel
            app.ImageintensityPanel = uipanel(app.GridLayout);
            app.ImageintensityPanel.BorderColor = [0.2196 0.149 0.2392];
            app.ImageintensityPanel.ForegroundColor = [1 1 1];
            app.ImageintensityPanel.HighlightColor = [0.2196 0.149 0.2392];
            app.ImageintensityPanel.TitlePosition = 'centertop';
            app.ImageintensityPanel.Title = 'Image intensity';
            app.ImageintensityPanel.BackgroundColor = [0.7804 0.6706 0.6706];
            app.ImageintensityPanel.Layout.Row = [2 11];
            app.ImageintensityPanel.Layout.Column = [2 8];
            app.ImageintensityPanel.FontSize = 14;

            % Create AdjustBrightnessButton
            app.AdjustBrightnessButton = uibutton(app.ImageintensityPanel, 'push');
            app.AdjustBrightnessButton.ButtonPushedFcn = createCallbackFcn(app, @AdjustBrightnessButtonPushed, true);
            app.AdjustBrightnessButton.BackgroundColor = [0.3412 0.2863 0.3922];
            app.AdjustBrightnessButton.FontColor = [1 1 1];
            app.AdjustBrightnessButton.Position = [83 31 145 29];
            app.AdjustBrightnessButton.Text = 'Adjust Brightness';

            % Create Low_inLabel
            app.Low_inLabel = uilabel(app.ImageintensityPanel);
            app.Low_inLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.Low_inLabel.FontColor = [1 1 1];
            app.Low_inLabel.Position = [25 254 53 22];
            app.Low_inLabel.Text = ' Low_in';

            % Create Low_inSlider
            app.Low_inSlider = uislider(app.ImageintensityPanel);
            app.Low_inSlider.Limits = [0 1];
            app.Low_inSlider.MajorTicks = [0 0.2 0.4 0.6 0.8 1];
            app.Low_inSlider.Position = [90 273 167 3];

            % Create High_inLabel
            app.High_inLabel = uilabel(app.ImageintensityPanel);
            app.High_inLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.High_inLabel.FontColor = [1 1 1];
            app.High_inLabel.Position = [25 197 53 22];
            app.High_inLabel.Text = ' High_in';

            % Create High_inSlider
            app.High_inSlider = uislider(app.ImageintensityPanel);
            app.High_inSlider.Limits = [0 1];
            app.High_inSlider.MajorTicks = [0 0.2 0.4 0.6 0.8 1];
            app.High_inSlider.Position = [94 215 163 3];

            % Create Low_outLabel
            app.Low_outLabel = uilabel(app.ImageintensityPanel);
            app.Low_outLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.Low_outLabel.FontColor = [1 1 1];
            app.Low_outLabel.Position = [25 147 54 22];
            app.Low_outLabel.Text = ' Low_out';

            % Create Low_outSlider
            app.Low_outSlider = uislider(app.ImageintensityPanel);
            app.Low_outSlider.Limits = [0 1];
            app.Low_outSlider.MajorTicks = [0 0.2 0.4 0.6 0.8 1];
            app.Low_outSlider.Position = [94 155 163 3];

            % Create High_outLabel
            app.High_outLabel = uilabel(app.ImageintensityPanel);
            app.High_outLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.High_outLabel.FontColor = [1 1 1];
            app.High_outLabel.Position = [25 89 56 22];
            app.High_outLabel.Text = ' High_out';

            % Create High_outSlider
            app.High_outSlider = uislider(app.ImageintensityPanel);
            app.High_outSlider.Limits = [0 1];
            app.High_outSlider.MajorTicks = [0 0.2 0.4 0.6 0.8 1];
            app.High_outSlider.Position = [94 108 163 3];

            % Create ImageIntensityLabel
            app.ImageIntensityLabel = uilabel(app.GridLayout);
            app.ImageIntensityLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.ImageIntensityLabel.HorizontalAlignment = 'center';
            app.ImageIntensityLabel.FontSize = 18;
            app.ImageIntensityLabel.FontColor = [1 1 1];
            app.ImageIntensityLabel.Layout.Row = 2;
            app.ImageIntensityLabel.Layout.Column = [2 8];
            app.ImageIntensityLabel.Text = 'Image Intensity';

            % Create frequencyfilteringPanel
            app.frequencyfilteringPanel = uipanel(app.GridLayout);
            app.frequencyfilteringPanel.BorderColor = [0.2196 0.149 0.2392];
            app.frequencyfilteringPanel.HighlightColor = [0.2196 0.149 0.2392];
            app.frequencyfilteringPanel.Title = 'frequency filtering';
            app.frequencyfilteringPanel.BackgroundColor = [0.7804 0.6706 0.6706];
            app.frequencyfilteringPanel.Layout.Row = [23 29];
            app.frequencyfilteringPanel.Layout.Column = [2 9];
            app.frequencyfilteringPanel.FontSize = 14;

            % Create LowpassfilterButtonGroup
            app.LowpassfilterButtonGroup = uibuttongroup(app.frequencyfilteringPanel);
            app.LowpassfilterButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @LowpassfilterButtonGroupSelectionChanged, true);
            app.LowpassfilterButtonGroup.BorderColor = [0.2196 0.149 0.2392];
            app.LowpassfilterButtonGroup.HighlightColor = [0.2196 0.149 0.2392];
            app.LowpassfilterButtonGroup.Title = 'Low-pass filter';
            app.LowpassfilterButtonGroup.Position = [21 56 123 116];

            % Create IdealButton
            app.IdealButton = uiradiobutton(app.LowpassfilterButtonGroup);
            app.IdealButton.Text = 'Ideal';
            app.IdealButton.Position = [11 48 58 22];

            % Create ButterworthButton
            app.ButterworthButton = uiradiobutton(app.LowpassfilterButtonGroup);
            app.ButterworthButton.Text = 'Butterworth';
            app.ButterworthButton.Position = [11 26 83 22];

            % Create GaussianButton
            app.GaussianButton = uiradiobutton(app.LowpassfilterButtonGroup);
            app.GaussianButton.Text = 'Gaussian';
            app.GaussianButton.Position = [11 4 72 22];

            % Create NoneButton_2
            app.NoneButton_2 = uiradiobutton(app.LowpassfilterButtonGroup);
            app.NoneButton_2.Text = 'None';
            app.NoneButton_2.Position = [11 69 58 22];
            app.NoneButton_2.Value = true;

            % Create HighpassfilterButtonGroup
            app.HighpassfilterButtonGroup = uibuttongroup(app.frequencyfilteringPanel);
            app.HighpassfilterButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @HighpassfilterButtonGroupSelectionChanged, true);
            app.HighpassfilterButtonGroup.BorderColor = [0.2196 0.149 0.2392];
            app.HighpassfilterButtonGroup.HighlightColor = [0.2196 0.149 0.2392];
            app.HighpassfilterButtonGroup.Title = 'High-pass filter';
            app.HighpassfilterButtonGroup.Position = [164 56 123 116];

            % Create IdealButton_2
            app.IdealButton_2 = uiradiobutton(app.HighpassfilterButtonGroup);
            app.IdealButton_2.Text = 'Ideal';
            app.IdealButton_2.Position = [11 48 58 22];

            % Create ButterworthButton_2
            app.ButterworthButton_2 = uiradiobutton(app.HighpassfilterButtonGroup);
            app.ButterworthButton_2.Text = 'Butterworth';
            app.ButterworthButton_2.Position = [11 26 83 22];

            % Create GaussianButton_2
            app.GaussianButton_2 = uiradiobutton(app.HighpassfilterButtonGroup);
            app.GaussianButton_2.Text = 'Gaussian';
            app.GaussianButton_2.Position = [11 4 72 22];

            % Create NoneButton_3
            app.NoneButton_3 = uiradiobutton(app.HighpassfilterButtonGroup);
            app.NoneButton_3.Text = 'None';
            app.NoneButton_3.Position = [11 69 58 22];
            app.NoneButton_3.Value = true;

            % Create CutoffLabel
            app.CutoffLabel = uilabel(app.frequencyfilteringPanel);
            app.CutoffLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.CutoffLabel.HorizontalAlignment = 'center';
            app.CutoffLabel.FontColor = [1 1 1];
            app.CutoffLabel.Position = [84 186 64 22];
            app.CutoffLabel.Text = 'Cutoff ';

            % Create CutoffSpinner
            app.CutoffSpinner = uispinner(app.frequencyfilteringPanel);
            app.CutoffSpinner.Step = 5;
            app.CutoffSpinner.Limits = [5 100];
            app.CutoffSpinner.BackgroundColor = [0.9412 0.9412 0.9412];
            app.CutoffSpinner.Position = [148 186 75 22];
            app.CutoffSpinner.Value = 5;

            % Create HighpassfilterLabel
            app.HighpassfilterLabel = uilabel(app.frequencyfilteringPanel);
            app.HighpassfilterLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.HighpassfilterLabel.HorizontalAlignment = 'center';
            app.HighpassfilterLabel.FontColor = [1 1 1];
            app.HighpassfilterLabel.Position = [164 150 123 22];
            app.HighpassfilterLabel.Text = 'High-pass filter';

            % Create LowpassfilterLabel
            app.LowpassfilterLabel = uilabel(app.frequencyfilteringPanel);
            app.LowpassfilterLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.LowpassfilterLabel.HorizontalAlignment = 'center';
            app.LowpassfilterLabel.FontColor = [1 1 1];
            app.LowpassfilterLabel.Position = [21 150 123 22];
            app.LowpassfilterLabel.Text = 'Low-pass filter';

            % Create SpatialFilteringPanel
            app.SpatialFilteringPanel = uipanel(app.GridLayout);
            app.SpatialFilteringPanel.BorderColor = [0.2196 0.149 0.2392];
            app.SpatialFilteringPanel.ForegroundColor = [1 1 1];
            app.SpatialFilteringPanel.HighlightColor = [0.2196 0.149 0.2392];
            app.SpatialFilteringPanel.TitlePosition = 'centertop';
            app.SpatialFilteringPanel.Title = 'Spatial Filtering';
            app.SpatialFilteringPanel.BackgroundColor = [0.7804 0.6706 0.6706];
            app.SpatialFilteringPanel.Layout.Row = [13 21];
            app.SpatialFilteringPanel.Layout.Column = [2 12];
            app.SpatialFilteringPanel.FontSize = 14;

            % Create SmoothingfilterButtonGroup
            app.SmoothingfilterButtonGroup = uibuttongroup(app.SpatialFilteringPanel);
            app.SmoothingfilterButtonGroup.BorderColor = [0.2196 0.149 0.2392];
            app.SmoothingfilterButtonGroup.HighlightColor = [0.2196 0.149 0.2392];
            app.SmoothingfilterButtonGroup.Title = 'Smoothing filter';
            app.SmoothingfilterButtonGroup.Position = [44 132 127 126];

            % Create BoxButton
            app.BoxButton = uiradiobutton(app.SmoothingfilterButtonGroup);
            app.BoxButton.Text = 'Box';
            app.BoxButton.Position = [6 70 58 22];
            app.BoxButton.Value = true;

            % Create AverageButton
            app.AverageButton = uiradiobutton(app.SmoothingfilterButtonGroup);
            app.AverageButton.Text = 'Average';
            app.AverageButton.Position = [6 48 66 22];

            % Create MedianButton
            app.MedianButton = uiradiobutton(app.SmoothingfilterButtonGroup);
            app.MedianButton.Text = 'Median';
            app.MedianButton.Position = [6 26 65 22];

            % Create ApplyfilterButton
            app.ApplyfilterButton = uibutton(app.SpatialFilteringPanel, 'push');
            app.ApplyfilterButton.ButtonPushedFcn = createCallbackFcn(app, @ApplyfilterButtonPushed, true);
            app.ApplyfilterButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.ApplyfilterButton.FontColor = [1 1 1];
            app.ApplyfilterButton.Position = [53 47 110 22];
            app.ApplyfilterButton.Text = 'Apply filter';

            % Create SharpeningfilterButtonGroup
            app.SharpeningfilterButtonGroup = uibuttongroup(app.SpatialFilteringPanel);
            app.SharpeningfilterButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @SharpeningfilterButtonGroupSelectionChanged, true);
            app.SharpeningfilterButtonGroup.BorderColor = [0.2196 0.149 0.2392];
            app.SharpeningfilterButtonGroup.HighlightColor = [0.2196 0.149 0.2392];
            app.SharpeningfilterButtonGroup.TitlePosition = 'centertop';
            app.SharpeningfilterButtonGroup.Title = 'Sharpening filter';
            app.SharpeningfilterButtonGroup.Position = [245 25 227 243];

            % Create Laplacian1stdervativeButton
            app.Laplacian1stdervativeButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.Laplacian1stdervativeButton.Text = 'Laplacian 1st dervative';
            app.Laplacian1stdervativeButton.Position = [13 168 144 22];

            % Create Laplacian2nddervativeButton
            app.Laplacian2nddervativeButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.Laplacian2nddervativeButton.Text = 'Laplacian 2nd dervative';
            app.Laplacian2nddervativeButton.Position = [13 146 148 22];

            % Create BoostedLaplacian1stdervativeButton
            app.BoostedLaplacian1stdervativeButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.BoostedLaplacian1stdervativeButton.Text = 'Boosted Laplacian 1st dervative';
            app.BoostedLaplacian1stdervativeButton.Position = [13 124 193 22];

            % Create BoostedLaplacian2nddervativeButton
            app.BoostedLaplacian2nddervativeButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.BoostedLaplacian2nddervativeButton.Text = 'Boosted Laplacian 2nd dervative';
            app.BoostedLaplacian2nddervativeButton.Position = [13 103 197 22];

            % Create NoneButton
            app.NoneButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.NoneButton.Text = 'None';
            app.NoneButton.Position = [13 189 50 22];
            app.NoneButton.Value = true;

            % Create SobelButton
            app.SobelButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.SobelButton.Text = 'Sobel';
            app.SobelButton.Position = [13 41 52 21];

            % Create BoostedSobelButton
            app.BoostedSobelButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.BoostedSobelButton.Text = 'Boosted Sobel';
            app.BoostedSobelButton.Position = [13 21 100 25];

            % Create PrewittButton
            app.PrewittButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.PrewittButton.Text = 'Prewitt';
            app.PrewittButton.Position = [13 3 58 21];

            % Create HorizontalSobelButton
            app.HorizontalSobelButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.HorizontalSobelButton.Text = 'Horizontal Sobel';
            app.HorizontalSobelButton.Position = [13 82 110 22];

            % Create VerticalSobelButton
            app.VerticalSobelButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.VerticalSobelButton.Text = 'Vertical Sobel';
            app.VerticalSobelButton.Position = [13 61 95 22];

            % Create SmoothingfilterLabel
            app.SmoothingfilterLabel = uilabel(app.SpatialFilteringPanel);
            app.SmoothingfilterLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.SmoothingfilterLabel.HorizontalAlignment = 'center';
            app.SmoothingfilterLabel.FontColor = [1 1 1];
            app.SmoothingfilterLabel.Position = [44 236 127 22];
            app.SmoothingfilterLabel.Text = 'Smoothing filter';

            % Create SharpeningfilterLabel
            app.SharpeningfilterLabel = uilabel(app.SpatialFilteringPanel);
            app.SharpeningfilterLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.SharpeningfilterLabel.HorizontalAlignment = 'center';
            app.SharpeningfilterLabel.FontColor = [1 1 1];
            app.SharpeningfilterLabel.Position = [245 246 227 22];
            app.SharpeningfilterLabel.Text = 'Sharpening filter';

            % Create Label
            app.Label = uilabel(app.SpatialFilteringPanel);
            app.Label.BackgroundColor = [0.3412 0.2902 0.3882];
            app.Label.FontColor = [1 1 1];
            app.Label.Position = [207 47 10 216];
            app.Label.Text = '';

            % Create Label_2
            app.Label_2 = uilabel(app.SpatialFilteringPanel);
            app.Label_2.BackgroundColor = [0.7804 0.6706 0.6706];
            app.Label_2.FontColor = [1 1 1];
            app.Label_2.Position = [212 47 10 217];
            app.Label_2.Text = '';

            % Create FilterSizeDropDownLabel
            app.FilterSizeDropDownLabel = uilabel(app.SpatialFilteringPanel);
            app.FilterSizeDropDownLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.FilterSizeDropDownLabel.HorizontalAlignment = 'center';
            app.FilterSizeDropDownLabel.FontColor = [1 1 1];
            app.FilterSizeDropDownLabel.Position = [11 92 81 22];
            app.FilterSizeDropDownLabel.Text = 'Filter Size';

            % Create FilterSizeDropDown
            app.FilterSizeDropDown = uidropdown(app.SpatialFilteringPanel);
            app.FilterSizeDropDown.Items = {'3X3', '5X5', '7X7', '9X9'};
            app.FilterSizeDropDown.Position = [91 92 100 22];
            app.FilterSizeDropDown.Value = '3X3';

            % Create FrequencydomainFilteringLabel
            app.FrequencydomainFilteringLabel = uilabel(app.GridLayout);
            app.FrequencydomainFilteringLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.FrequencydomainFilteringLabel.HorizontalAlignment = 'center';
            app.FrequencydomainFilteringLabel.FontSize = 18;
            app.FrequencydomainFilteringLabel.FontColor = [1 1 1];
            app.FrequencydomainFilteringLabel.Layout.Row = 23;
            app.FrequencydomainFilteringLabel.Layout.Column = [2 9];
            app.FrequencydomainFilteringLabel.Text = 'Frequency-domain Filtering';

            % Create ColorspaceconversionButtonGroup
            app.ColorspaceconversionButtonGroup = uibuttongroup(app.GridLayout);
            app.ColorspaceconversionButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @ColorspaceconversionButtonGroupSelectionChanged, true);
            app.ColorspaceconversionButtonGroup.BorderColor = [0.3412 0.2902 0.3882];
            app.ColorspaceconversionButtonGroup.HighlightColor = [0.3412 0.2902 0.3882];
            app.ColorspaceconversionButtonGroup.TitlePosition = 'centertop';
            app.ColorspaceconversionButtonGroup.Title = 'Color space conversion';
            app.ColorspaceconversionButtonGroup.BackgroundColor = [0.7804 0.6706 0.6706];
            app.ColorspaceconversionButtonGroup.Layout.Row = [23 25];
            app.ColorspaceconversionButtonGroup.Layout.Column = [11 14];

            % Create rgbButton
            app.rgbButton = uiradiobutton(app.ColorspaceconversionButtonGroup);
            app.rgbButton.Text = 'rgb';
            app.rgbButton.Position = [11 38 58 22];
            app.rgbButton.Value = true;

            % Create labButton
            app.labButton = uiradiobutton(app.ColorspaceconversionButtonGroup);
            app.labButton.Text = 'lab';
            app.labButton.Position = [10 11 65 22];

            % Create YCbCrButton
            app.YCbCrButton = uiradiobutton(app.ColorspaceconversionButtonGroup);
            app.YCbCrButton.Text = 'YCbCr';
            app.YCbCrButton.Position = [84 38 65 22];

            % Create HSVButton
            app.HSVButton = uiradiobutton(app.ColorspaceconversionButtonGroup);
            app.HSVButton.Text = 'HSV';
            app.HSVButton.Position = [84 11 50 22];

            % Create HistogramEqualizationButton
            app.HistogramEqualizationButton = uibutton(app.GridLayout, 'push');
            app.HistogramEqualizationButton.ButtonPushedFcn = createCallbackFcn(app, @HistogramEqualizationButtonPushed, true);
            app.HistogramEqualizationButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.HistogramEqualizationButton.FontSize = 14;
            app.HistogramEqualizationButton.FontColor = [1 1 1];
            app.HistogramEqualizationButton.Layout.Row = [27 28];
            app.HistogramEqualizationButton.Layout.Column = [11 14];
            app.HistogramEqualizationButton.Text = {'Histogram '; 'Equalization'};

            % Create ColorspaceconversionLabel
            app.ColorspaceconversionLabel = uilabel(app.GridLayout);
            app.ColorspaceconversionLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.ColorspaceconversionLabel.HorizontalAlignment = 'center';
            app.ColorspaceconversionLabel.FontColor = [1 1 1];
            app.ColorspaceconversionLabel.Layout.Row = 23;
            app.ColorspaceconversionLabel.Layout.Column = [11 14];
            app.ColorspaceconversionLabel.Text = 'Color space conversion';

            % Create uploadphotoButton
            app.uploadphotoButton = uibutton(app.GridLayout, 'push');
            app.uploadphotoButton.ButtonPushedFcn = createCallbackFcn(app, @uploadphotoButtonPushed, true);
            app.uploadphotoButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.uploadphotoButton.FontSize = 14;
            app.uploadphotoButton.FontColor = [1 1 1];
            app.uploadphotoButton.Layout.Row = 11;
            app.uploadphotoButton.Layout.Column = [13 16];
            app.uploadphotoButton.Text = 'upload photo';

            % Create resetButton
            app.resetButton = uibutton(app.GridLayout, 'push');
            app.resetButton.ButtonPushedFcn = createCallbackFcn(app, @resetButtonPushed, true);
            app.resetButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.resetButton.FontSize = 14;
            app.resetButton.FontColor = [1 1 1];
            app.resetButton.Layout.Row = 11;
            app.resetButton.Layout.Column = [23 26];
            app.resetButton.Text = 'reset';

            % Create SpatialdomainFilteringLabel
            app.SpatialdomainFilteringLabel = uilabel(app.GridLayout);
            app.SpatialdomainFilteringLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.SpatialdomainFilteringLabel.HorizontalAlignment = 'center';
            app.SpatialdomainFilteringLabel.FontSize = 18;
            app.SpatialdomainFilteringLabel.FontColor = [1 1 1];
            app.SpatialdomainFilteringLabel.Layout.Row = 13;
            app.SpatialdomainFilteringLabel.Layout.Column = [2 12];
            app.SpatialdomainFilteringLabel.Text = 'Spatial-domain Filtering';

            % Create pyramidPanel
            app.pyramidPanel = uipanel(app.GridLayout);
            app.pyramidPanel.Title = 'pyramid';
            app.pyramidPanel.BackgroundColor = [0.7804 0.6706 0.6706];
            app.pyramidPanel.Layout.Row = [13 16];
            app.pyramidPanel.Layout.Column = [14 17];

            % Create ApplypyramidButton
            app.ApplypyramidButton = uibutton(app.pyramidPanel, 'push');
            app.ApplypyramidButton.ButtonPushedFcn = createCallbackFcn(app, @ApplypyramidButtonPushed, true);
            app.ApplypyramidButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.ApplypyramidButton.FontColor = [1 1 1];
            app.ApplypyramidButton.Position = [23 25 128 24];
            app.ApplypyramidButton.Text = 'Apply pyramid';

            % Create ImagepyramidDropDownLabel
            app.ImagepyramidDropDownLabel = uilabel(app.GridLayout);
            app.ImagepyramidDropDownLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.ImagepyramidDropDownLabel.HorizontalAlignment = 'center';
            app.ImagepyramidDropDownLabel.FontColor = [1 1 1];
            app.ImagepyramidDropDownLabel.Layout.Row = 13;
            app.ImagepyramidDropDownLabel.Layout.Column = [14 17];
            app.ImagepyramidDropDownLabel.Text = 'Image pyramid';

            % Create ImagepyramidDropDown
            app.ImagepyramidDropDown = uidropdown(app.GridLayout);
            app.ImagepyramidDropDown.Items = {'reduce', 'expand'};
            app.ImagepyramidDropDown.BackgroundColor = [0.9412 0.9412 0.9412];
            app.ImagepyramidDropDown.Layout.Row = 14;
            app.ImagepyramidDropDown.Layout.Column = [15 16];
            app.ImagepyramidDropDown.Value = 'reduce';

            % Create templatematchingPanel
            app.templatematchingPanel = uipanel(app.GridLayout);
            app.templatematchingPanel.Title = 'template matching';
            app.templatematchingPanel.BackgroundColor = [0.7804 0.6706 0.6706];
            app.templatematchingPanel.Layout.Row = [13 23];
            app.templatematchingPanel.Layout.Column = [19 24];

            % Create UIAxes3
            app.UIAxes3 = uiaxes(app.templatematchingPanel);
            title(app.UIAxes3, 'Template patch')
            zlabel(app.UIAxes3, 'Z')
            app.UIAxes3.XTick = [];
            app.UIAxes3.YTick = [];
            app.UIAxes3.Box = 'on';
            app.UIAxes3.Position = [19 89 233 154];

            % Create UploadtemplateButton
            app.UploadtemplateButton = uibutton(app.templatematchingPanel, 'push');
            app.UploadtemplateButton.ButtonPushedFcn = createCallbackFcn(app, @UploadtemplateButtonPushed, true);
            app.UploadtemplateButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.UploadtemplateButton.FontColor = [1 1 1];
            app.UploadtemplateButton.Position = [48 296 183 24];
            app.UploadtemplateButton.Text = 'Upload template';

            % Create MatchthetemplateButton
            app.MatchthetemplateButton = uibutton(app.templatematchingPanel, 'push');
            app.MatchthetemplateButton.ButtonPushedFcn = createCallbackFcn(app, @MatchthetemplateButtonPushed, true);
            app.MatchthetemplateButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.MatchthetemplateButton.FontColor = [1 1 1];
            app.MatchthetemplateButton.Position = [48 18 183 25];
            app.MatchthetemplateButton.Text = 'Match the template';

            % Create MatchTechniqueDropDown
            app.MatchTechniqueDropDown = uidropdown(app.templatematchingPanel);
            app.MatchTechniqueDropDown.Items = {'ZMCC', 'SSD', 'NCC'};
            app.MatchTechniqueDropDown.Position = [48 53 183 25];
            app.MatchTechniqueDropDown.Value = 'ZMCC';

            % Create SelectTemplateFromImageButton
            app.SelectTemplateFromImageButton = uibutton(app.templatematchingPanel, 'push');
            app.SelectTemplateFromImageButton.ButtonPushedFcn = createCallbackFcn(app, @SelectTemplateFromImageButtonPushed, true);
            app.SelectTemplateFromImageButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.SelectTemplateFromImageButton.FontColor = [1 1 1];
            app.SelectTemplateFromImageButton.Position = [48 262 183 24];
            app.SelectTemplateFromImageButton.Text = 'Select Template From Image ';

            % Create ImagepyramidDropDownLabel_2
            app.ImagepyramidDropDownLabel_2 = uilabel(app.GridLayout);
            app.ImagepyramidDropDownLabel_2.BackgroundColor = [0.3412 0.2902 0.3882];
            app.ImagepyramidDropDownLabel_2.HorizontalAlignment = 'center';
            app.ImagepyramidDropDownLabel_2.FontSize = 14;
            app.ImagepyramidDropDownLabel_2.FontColor = [1 1 1];
            app.ImagepyramidDropDownLabel_2.Layout.Row = 13;
            app.ImagepyramidDropDownLabel_2.Layout.Column = [19 24];
            app.ImagepyramidDropDownLabel_2.Text = 'Template Matching';

            % Create Panel
            app.Panel = uipanel(app.GridLayout);
            app.Panel.Title = 'Panel';
            app.Panel.BackgroundColor = [0.7804 0.6706 0.6706];
            app.Panel.Layout.Row = [18 21];
            app.Panel.Layout.Column = [14 17];

            % Create applyfilterButton
            app.applyfilterButton = uibutton(app.Panel, 'push');
            app.applyfilterButton.ButtonPushedFcn = createCallbackFcn(app, @applyfilterButtonPushed, true);
            app.applyfilterButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.applyfilterButton.FontColor = [1 1 1];
            app.applyfilterButton.Position = [39 23 96 24];
            app.applyfilterButton.Text = 'apply filter';

            % Create LMfilterSpinnerLabel
            app.LMfilterSpinnerLabel = uilabel(app.Panel);
            app.LMfilterSpinnerLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.LMfilterSpinnerLabel.HorizontalAlignment = 'center';
            app.LMfilterSpinnerLabel.FontColor = [1 1 1];
            app.LMfilterSpinnerLabel.Position = [11 65 74 25];
            app.LMfilterSpinnerLabel.Text = 'LM filter';

            % Create LMfilterSpinner
            app.LMfilterSpinner = uispinner(app.Panel);
            app.LMfilterSpinner.Limits = [1 48];
            app.LMfilterSpinner.Position = [85 65 86 25];
            app.LMfilterSpinner.Value = 1;

            % Create LMFilterBankLabel
            app.LMFilterBankLabel = uilabel(app.GridLayout);
            app.LMFilterBankLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.LMFilterBankLabel.HorizontalAlignment = 'center';
            app.LMFilterBankLabel.FontColor = [1 1 1];
            app.LMFilterBankLabel.Layout.Row = 18;
            app.LMFilterBankLabel.Layout.Column = [14 17];
            app.LMFilterBankLabel.Text = 'LM Filter Bank';

            % Create Panel2
            app.Panel2 = uipanel(app.GridLayout);
            app.Panel2.Title = 'Panel2';
            app.Panel2.BackgroundColor = [0.7804 0.6706 0.6706];
            app.Panel2.Layout.Row = [13 18];
            app.Panel2.Layout.Column = [26 30];

            % Create DetectEdgesButton
            app.DetectEdgesButton = uibutton(app.Panel2, 'push');
            app.DetectEdgesButton.ButtonPushedFcn = createCallbackFcn(app, @DetectEdgesButtonPushed, true);
            app.DetectEdgesButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.DetectEdgesButton.FontColor = [1 1 1];
            app.DetectEdgesButton.Position = [65 8 132 26];
            app.DetectEdgesButton.Text = 'Detect Edges';

            % Create LowthresholdSpinnerLabel
            app.LowthresholdSpinnerLabel = uilabel(app.Panel2);
            app.LowthresholdSpinnerLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.LowthresholdSpinnerLabel.HorizontalAlignment = 'center';
            app.LowthresholdSpinnerLabel.FontColor = [1 1 1];
            app.LowthresholdSpinnerLabel.Position = [34 128 109 24];
            app.LowthresholdSpinnerLabel.Text = 'Low threshold';

            % Create LowthresholdSpinner
            app.LowthresholdSpinner = uispinner(app.Panel2);
            app.LowthresholdSpinner.Step = 0.01;
            app.LowthresholdSpinner.Limits = [0.01 0.4];
            app.LowthresholdSpinner.HorizontalAlignment = 'center';
            app.LowthresholdSpinner.Position = [143 128 85 24];
            app.LowthresholdSpinner.Value = 0.1;

            % Create HighthreshholdSpinnerLabel
            app.HighthreshholdSpinnerLabel = uilabel(app.Panel2);
            app.HighthreshholdSpinnerLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.HighthreshholdSpinnerLabel.HorizontalAlignment = 'center';
            app.HighthreshholdSpinnerLabel.FontColor = [1 1 1];
            app.HighthreshholdSpinnerLabel.Position = [34 90 110 25];
            app.HighthreshholdSpinnerLabel.Text = 'High threshhold';

            % Create HighthreshholdSpinner
            app.HighthreshholdSpinner = uispinner(app.Panel2);
            app.HighthreshholdSpinner.Step = 0.01;
            app.HighthreshholdSpinner.Limits = [0.1 0.99];
            app.HighthreshholdSpinner.HorizontalAlignment = 'center';
            app.HighthreshholdSpinner.Position = [144 90 85 25];
            app.HighthreshholdSpinner.Value = 0.3;

            % Create SigmaSpinnerLabel
            app.SigmaSpinnerLabel = uilabel(app.Panel2);
            app.SigmaSpinnerLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.SigmaSpinnerLabel.HorizontalAlignment = 'center';
            app.SigmaSpinnerLabel.FontColor = [1 1 1];
            app.SigmaSpinnerLabel.Position = [34 52 110 25];
            app.SigmaSpinnerLabel.Text = 'Sigma';

            % Create SigmaSpinner
            app.SigmaSpinner = uispinner(app.Panel2);
            app.SigmaSpinner.Step = 0.1;
            app.SigmaSpinner.Limits = [0.5 5];
            app.SigmaSpinner.HorizontalAlignment = 'center';
            app.SigmaSpinner.Position = [144 52 85 25];
            app.SigmaSpinner.Value = 1;

            % Create CannyEdgeDetectionLabel
            app.CannyEdgeDetectionLabel = uilabel(app.GridLayout);
            app.CannyEdgeDetectionLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.CannyEdgeDetectionLabel.HorizontalAlignment = 'center';
            app.CannyEdgeDetectionLabel.FontColor = [1 1 1];
            app.CannyEdgeDetectionLabel.Layout.Row = 13;
            app.CannyEdgeDetectionLabel.Layout.Column = [26 30];
            app.CannyEdgeDetectionLabel.Text = 'Canny Edge Detection';

            % Create Panel3
            app.Panel3 = uipanel(app.GridLayout);
            app.Panel3.Title = 'Panel3';
            app.Panel3.BackgroundColor = [0.7804 0.6706 0.6706];
            app.Panel3.Layout.Row = [20 26];
            app.Panel3.Layout.Column = [26 30];

            % Create FilterSizeDropDown_2Label
            app.FilterSizeDropDown_2Label = uilabel(app.Panel3);
            app.FilterSizeDropDown_2Label.BackgroundColor = [0.3412 0.2902 0.3882];
            app.FilterSizeDropDown_2Label.HorizontalAlignment = 'center';
            app.FilterSizeDropDown_2Label.FontColor = [1 1 1];
            app.FilterSizeDropDown_2Label.Position = [41 131 81 22];
            app.FilterSizeDropDown_2Label.Text = 'FilterSize';

            % Create FilterSizeDropDown_2
            app.FilterSizeDropDown_2 = uidropdown(app.Panel3);
            app.FilterSizeDropDown_2.Items = {'3X3', '5X5', '7X7', '9X9', '11X11'};
            app.FilterSizeDropDown_2.Position = [121 131 99 22];
            app.FilterSizeDropDown_2.Value = '5X5';

            % Create MinQualitySpinnerLabel
            app.MinQualitySpinnerLabel = uilabel(app.Panel3);
            app.MinQualitySpinnerLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.MinQualitySpinnerLabel.HorizontalAlignment = 'center';
            app.MinQualitySpinnerLabel.FontColor = [1 1 1];
            app.MinQualitySpinnerLabel.Position = [42 165 81 22];
            app.MinQualitySpinnerLabel.Text = 'MinQuality';

            % Create MinQualitySpinner
            app.MinQualitySpinner = uispinner(app.Panel3);
            app.MinQualitySpinner.Step = 0.01;
            app.MinQualitySpinner.Limits = [0.01 0.2];
            app.MinQualitySpinner.HorizontalAlignment = 'center';
            app.MinQualitySpinner.Position = [122 165 99 22];
            app.MinQualitySpinner.Value = 0.01;

            % Create DetectCornersButton
            app.DetectCornersButton = uibutton(app.Panel3, 'push');
            app.DetectCornersButton.ButtonPushedFcn = createCallbackFcn(app, @DetectCornersButtonPushed, true);
            app.DetectCornersButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.DetectCornersButton.FontColor = [1 1 1];
            app.DetectCornersButton.Position = [82 17 100 22];
            app.DetectCornersButton.Text = 'Detect Corners';

            % Create CornerDetectionLabel
            app.CornerDetectionLabel = uilabel(app.Panel3);
            app.CornerDetectionLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.CornerDetectionLabel.HorizontalAlignment = 'center';
            app.CornerDetectionLabel.FontColor = [1 1 1];
            app.CornerDetectionLabel.Position = [1 215 263 26];
            app.CornerDetectionLabel.Text = 'Corner Detection';

            % Create NumberofCornersSpinnerLabel
            app.NumberofCornersSpinnerLabel = uilabel(app.Panel3);
            app.NumberofCornersSpinnerLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.NumberofCornersSpinnerLabel.HorizontalAlignment = 'center';
            app.NumberofCornersSpinnerLabel.FontColor = [1 1 1];
            app.NumberofCornersSpinnerLabel.Position = [45 59 107 22];
            app.NumberofCornersSpinnerLabel.Text = 'Number of Corners';

            % Create NumberofCornersSpinner
            app.NumberofCornersSpinner = uispinner(app.Panel3);
            app.NumberofCornersSpinner.Limits = [1 300];
            app.NumberofCornersSpinner.Position = [151 59 74 22];
            app.NumberofCornersSpinner.Value = 20;

            % Create ApplytothewholeimageCheckBox
            app.ApplytothewholeimageCheckBox = uicheckbox(app.Panel3);
            app.ApplytothewholeimageCheckBox.Text = 'Apply to the whole image';
            app.ApplytothewholeimageCheckBox.Position = [53 95 156 22];

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = temp_task_2_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end