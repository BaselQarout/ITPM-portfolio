classdef task_1_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                       matlab.ui.Figure
        FrequencydomainFilteringLabel  matlab.ui.control.Label
        frequencyfilteringPanel        matlab.ui.container.Panel
        CutoffSpinner                  matlab.ui.control.Spinner
        CutoffLabel                    matlab.ui.control.Label
        HighpassfilterButtonGroup      matlab.ui.container.ButtonGroup
        HighpassfilterLabel            matlab.ui.control.Label
        NoneButton_3                   matlab.ui.control.RadioButton
        GaussianButton_2               matlab.ui.control.RadioButton
        ButterworthButton_2            matlab.ui.control.RadioButton
        IdealButton_2                  matlab.ui.control.RadioButton
        LowpassfilterButtonGroup       matlab.ui.container.ButtonGroup
        LowpassfilterLabel             matlab.ui.control.Label
        NoneButton_2                   matlab.ui.control.RadioButton
        GaussianButton                 matlab.ui.control.RadioButton
        ButterworthButton              matlab.ui.control.RadioButton
        IdealButton                    matlab.ui.control.RadioButton
        ImageIntensityLabel            matlab.ui.control.Label
        ImageintensityPanel            matlab.ui.container.Panel
        High_outSlider                 matlab.ui.control.Slider
        High_outLabel                  matlab.ui.control.Label
        Low_outSlider                  matlab.ui.control.Slider
        Low_outLabel                   matlab.ui.control.Label
        High_inSlider                  matlab.ui.control.Slider
        High_inLabel                   matlab.ui.control.Label
        Low_inSlider                   matlab.ui.control.Slider
        Low_inLabel                    matlab.ui.control.Label
        AdjustBrightnessButton         matlab.ui.control.Button
        SpatialdomainFilteringLabel    matlab.ui.control.Label
        SpatialFilteringPanel          matlab.ui.container.Panel
        FilterSizeDropDown             matlab.ui.control.DropDown
        FilterSizeDropDownLabel        matlab.ui.control.Label
        Label_2                        matlab.ui.control.Label
        Label                          matlab.ui.control.Label
        SharpeningfilterLabel          matlab.ui.control.Label
        SmoothingfilterLabel           matlab.ui.control.Label
        SharpeningfilterButtonGroup    matlab.ui.container.ButtonGroup
        VerticalSobelButton            matlab.ui.control.RadioButton
        HorizontalSobelButton          matlab.ui.control.RadioButton
        PrewittButton                  matlab.ui.control.RadioButton
        BoostedSobelButton             matlab.ui.control.RadioButton
        SobelButton                    matlab.ui.control.RadioButton
        NoneButton                     matlab.ui.control.RadioButton
        BoostedLaplacian2nddervativeButton  matlab.ui.control.RadioButton
        BoostedLaplacian1stdervativeButton  matlab.ui.control.RadioButton
        Laplacian2nddervativeButton    matlab.ui.control.RadioButton
        Laplacian1stdervativeButton    matlab.ui.control.RadioButton
        ApplyfilterButton              matlab.ui.control.Button
        SmoothingfilterButtonGroup     matlab.ui.container.ButtonGroup
        MedianButton                   matlab.ui.control.RadioButton
        AverageButton                  matlab.ui.control.RadioButton
        BoxButton                      matlab.ui.control.RadioButton
        ColorspaceconversionButtonGroup  matlab.ui.container.ButtonGroup
        ColorspaceconversionLabel      matlab.ui.control.Label
        HSVButton                      matlab.ui.control.RadioButton
        YCbCrButton                    matlab.ui.control.RadioButton
        labButton                      matlab.ui.control.RadioButton
        rgbButton                      matlab.ui.control.RadioButton
        resetButton                    matlab.ui.control.Button
        HistogramEqualizationButton    matlab.ui.control.Button
        uploadphotoButton              matlab.ui.control.Button
        UIAxes                         matlab.ui.control.UIAxes
    end

    
    properties (Access = private)
        img % Description
        mod_img;
        cond = false;
        current_space = "rgb";
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            set(app.UIFigure, 'WindowState', 'maximized');
        end

        % Button pushed function: uploadphotoButton
        function uploadphotoButtonPushed(app, event)
           [file,path]=uigetfile({'*.jpg;*.png;*.bmp;*.tif', 'Image Files (*.jpg, *.png, *.bmp, *.tif)'});
           
           app.img=imread(fullfile(path,file));
           app.mod_img=app.img;
           
           imshow(app.mod_img,'Parent',app.UIAxes)

           figure(app.UIFigure);
           drawnow;
           set(app.UIFigure, 'WindowState', 'maximized');
        end

        % Button pushed function: AdjustBrightnessButton
        function AdjustBrightnessButtonPushed(app, event)
             if isempty(app.mod_img)
                return;
             end

             app.cond=true;
             low_in = max(0, min(app.Low_inSlider.Value, app.High_inSlider.Value-0.01));
             high_in = min(1, max(app.High_inSlider.Value, app.Low_inSlider.Value+0.01));
            
             % Update sliders to validated values
             app.Low_inSlider.Value = low_in;
             app.High_inSlider.Value = high_in;
            
             % Get output ranges
             low_out = app.Low_outSlider.Value;
             high_out = app.High_outSlider.Value;
            
             % Apply to processed image (not original)
             finalImage = imadjust(app.mod_img, [low_in high_in], [low_out high_out]);
            
             % Display result
             imshow(finalImage, "Parent", app.UIAxes)
        end

        % Button pushed function: HistogramEqualizationButton
        function HistogramEqualizationButtonPushed(app, event)
            if isempty(app.mod_img)
                return;
            end

            app.mod_img=histeq(app.mod_img);

            if(app.cond==true)
                    AdjustBrightnessButtonPushed(app,event);
                    return;
            end
                imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Button pushed function: ApplyfilterButton
        function ApplyfilterButtonPushed(app, event)
            if isempty(app.mod_img)
                return;
            end

            selectedFilter=app.SmoothingfilterButtonGroup.SelectedObject.Text;
            selectedSize=app.FilterSizeDropDown.Value;
            switch selectedFilter
                case "Box"
                    switch selectedSize
                        case "3X3"
                            filter = (1/9).*[1 1 1; 1 1 1; 1 1 1];
                        case "5X5"
                            filter = (1/25).* ones(5,5);
                        case "7X7"
                            filter = (1/49).* ones(7,7);
                        case "9X9"
                            filter = (1/81).*ones(9,9);
                    end
                           
                case "Average"
                    switch selectedSize
                        case "3X3"
                            filter = (1/16).*[1 2 1; 2 4 2; 1 2 1];
                        case "5X5"
                            filter = (1/65).*[1 2 2 2 1; 
                                               1 2 4 2 1;
                                               2 4 8 4 2;
                                               1 2 4 2 1;
                                               1 2 2 2 1];
                        case "7X7"
                            filter = (1/128).*[1 1 1 2 1 1 1; 
                                              1 1 2 4 1 1 2;
                                              1 2 4 8 4 2 1;
                                              2 4 8 16 8 4 2;
                                              1 2 4 8 4 2 1;
                                              1 1 2 4 1 1 2;
                                              1 1 1 2 1 1 1];
                        case "9X9"
                            filter = (1/280).*[1 1 1 1 2 1 1 1 1;
                                                1 1 1 2 4 2 1 1 1; 
                                                1 1 2 4 8 4 2 1 1;
                                                1 2 4 8 16 8 4 2 1;
                                                2 4 8 16 32 16 8 4 2;
                                                1 2 4 8 16 8 4 2 1;
                                                1 1 2 4 8 4 2 1 1;
                                                1 1 1 2 4 2 1 1 1;
                                                1 1 1 1 2 1 1 1 1];
                    end
                case "Median"
                    switch selectedSize
                        case "3X3"
                            if size(app.mod_img, 3) == 3
                                app.mod_img(:,:,1) = medfilt2(app.mod_img(:,:,1), [3 3]);
                                app.mod_img(:,:,2) = medfilt2(app.mod_img(:,:,2), [3 3]);
                                app.mod_img(:,:,3) = medfilt2(app.mod_img(:,:,3), [3 3]);
                            else
                                app.mod_img=medfilt2(app.mod_img, [3 3]);
                            end
                            if(app.cond==true)
                                AdjustBrightnessButtonPushed(app,event);
                                return;
                            end
                            imshow(app.mod_img,"Parent",app.UIAxes)
                            return;
                        case "5X5"
                            if size(app.mod_img, 3) == 3
                                app.mod_img(:,:,1) = medfilt2(app.mod_img(:,:,1), [5 5]);
                                app.mod_img(:,:,2) = medfilt2(app.mod_img(:,:,2), [5 5]);
                                app.mod_img(:,:,3) = medfilt2(app.mod_img(:,:,3), [5 5]);
                            else
                                app.mod_img=medfilt2(app.mod_img, [5 5]);
                            end
                            if(app.cond==true)
                                AdjustBrightnessButtonPushed(app,event);
                                return;
                            end
                            imshow(app.mod_img,"Parent",app.UIAxes)
                            return;
                        case "7X7"
                            if size(app.mod_img, 3) == 3
                                app.mod_img(:,:,1) = medfilt2(app.mod_img(:,:,1), [7 7]);
                                app.mod_img(:,:,2) = medfilt2(app.mod_img(:,:,2), [7 7]);
                                app.mod_img(:,:,3) = medfilt2(app.mod_img(:,:,3), [7 7]);
                            else
                                app.mod_img=medfilt2(app.mod_img, [7 7]);
                            end
                            if(app.cond==true)
                                AdjustBrightnessButtonPushed(app,event);
                                return;
                            end
                            imshow(app.mod_img,"Parent",app.UIAxes)
                            return;
                        case "9X9"
                            if size(app.mod_img, 3) == 3
                                app.mod_img(:,:,1) = medfilt2(app.mod_img(:,:,1), [9 9]);
                                app.mod_img(:,:,2) = medfilt2(app.mod_img(:,:,2), [9 9]);
                                app.mod_img(:,:,3) = medfilt2(app.mod_img(:,:,3), [9 9]);
                            else
                                app.mod_img=medfilt2(app.mod_img, [9 9]);
                            end
                            if(app.cond==true)
                                AdjustBrightnessButtonPushed(app,event);
                                return;
                            end
                            imshow(app.mod_img,"Parent",app.UIAxes)
                            return;
                            
                    end
            end
            app.mod_img=imfilter(app.mod_img,filter);
            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Button pushed function: resetButton
        function resetButtonPushed(app, event)
            app.cond=false;
            app.current_space = "rgb";
            app.Low_inSlider.Value = 0;
            app.Low_outSlider.Value = 0;
            app.High_inSlider.Value = 0;
            app.High_outSlider.Value = 0;
            app.SmoothingfilterButtonGroup.SelectedObject = app.BoxButton;
            app.SharpeningfilterButtonGroup.SelectedObject = app.NoneButton;
            app.FilterSizeDropDown.Value = "3X3";
            app.LowpassfilterButtonGroup.SelectedObject = app.NoneButton_2;
            app.HighpassfilterButtonGroup.SelectedObject = app.NoneButton_3;
            app.CutoffSpinner.Value = 5;
            app.ColorspaceconversionButtonGroup.SelectedObject = app.rgbButton;

            if isempty(app.mod_img)
                return;
            end
            
            app.mod_img=app.img;

            imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Selection changed function: SharpeningfilterButtonGroup
        function SharpeningfilterButtonGroupSelectionChanged(app, event)
            if isempty(app.mod_img)
                return;
            end
            
            selectedButton = app.SharpeningfilterButtonGroup.SelectedObject.Text;
             A = 3.5;
            
             switch selectedButton

                case "Laplacian 1st dervative"
                    filter = [0 -1 0; -1 4 -1; 0 -1 0];

                case "Laplacian 2nd dervative"
                    filter = [-1 -1 -1; -1 8 -1; -1 -1 -1];

                case "Boosted Laplacian 1st dervative"
                    filter = [0 -1 0; -1 4+A -1; 0 -1 0];

                case "Boosted Laplacian 2nd dervative"
                    filter = [-1 -1 -1; -1 8+A -1; -1 -1 -1];
                
                 case "Vertical Sobel"
                    filter = [-1 0 1; -2 0 2; -1 0 1];

                case "Horizontal Sobel"
                    filter = [-1 -2 -1; 0 0 0; 1 2 1];

                case "Sobel"
                    filter_X = [-1 0 1; -2 0 2; -1 0 1];
                    filter_Y = filter_X';

                    Hor_temp = imfilter(double(app.mod_img),filter_X);
                    Hor_temp = app.mod_img + uint8(Hor_temp);

                    ver_temp = imfilter(double(app.mod_img),filter_Y);
                    ver_temp = app.mod_img + uint8(ver_temp);
                    
                    app.mod_img = Hor_temp + ver_temp;

                    if(app.cond==true)
                        AdjustBrightnessButtonPushed(app,event);
                        return;
                    end
                    imshow(app.mod_img,"Parent",app.UIAxes)
                    return;
        
                case "Boosted Sobel"
                    filter_X = [-1 -2-A -1; 0 0 0; 1 2+A 1];
                    filter_Y = filter_X';

                    Hor_temp = imfilter(double(app.mod_img),filter_X);
                    Hor_temp = app.mod_img + uint8(Hor_temp);

                    ver_temp = imfilter(double(app.mod_img),filter_Y);
                    ver_temp = app.mod_img + uint8(ver_temp);
                    
                    app.mod_img = Hor_temp + ver_temp;

                    if(app.cond==true)
                        AdjustBrightnessButtonPushed(app,event);
                        return;
                    end
                    imshow(app.mod_img,"Parent",app.UIAxes)
                    return;
                
                 case "Prewitt"
                    filter_X = [-1 0 1; -1 0 1; -1 0 1];
                    filter_Y = filter_X';
                    
                    gray_img = rgb2gray(app.mod_img);
                    
                    gray_img = double(gray_img);
                    
                    Gx = imfilter(gray_img, filter_X);
                    Gy = imfilter(gray_img, filter_Y);
                    
                    edge_magnitude = sqrt(Gx.^2 + Gy.^2);
                    
                    edge_magnitude = uint8(255 * mat2gray(edge_magnitude));
                    
                    edge_rgb = cat(3, edge_magnitude, edge_magnitude, edge_magnitude);
                    app.mod_img = edge_rgb;

                    if(app.cond==true)
                        AdjustBrightnessButtonPushed(app,event);
                        return;
                    end
                    imshow(app.mod_img,"Parent",app.UIAxes)
                    return;

                otherwise
                    return;
            end

            filtered=imfilter(app.mod_img,filter);
            app.mod_img = app.mod_img + uint8(filtered);
            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
        end

        % Selection changed function: LowpassfilterButtonGroup
        function LowpassfilterButtonGroupSelectionChanged(app, event)
            if isempty(app.mod_img)
                return;
            end
            
            selectedButton = app.LowpassfilterButtonGroup.SelectedObject.Text;
            
            % Convert to grayscale if RGB
            if size(app.mod_img, 3) == 3
                img_gray = rgb2gray(app.mod_img);
            else
                img_gray = app.mod_img;
            end
            
            % Get frequency domain representation
            FI = fftshift(fft2(double(img_gray)));
            [m,n] = size(img_gray);
            [X,Y] = meshgrid(1:n,1:m);
            X = X-(n+1)/2; 
            Y = Y-(m+1)/2;
            D = sqrt(X.^2+Y.^2);
            
            % Get cutoff frequency from spinner
            D0 = app.CutoffSpinner.Value;

            switch selectedButton
            case "Ideal"
                % Ideal Low-pass Filter
                ILPF = D < D0;
                filtered = ifft2(fftshift(FI.*ILPF));
                
            case "Butterworth"
                % Butterworth Low-pass Filter
                n = 1; % order
                BLPF = 1 ./ (1.0 + (D./D0).^(2*n));
                filtered = ifft2(fftshift(FI.*BLPF));
                
            case "Gaussian"
                % Gaussian Low-pass Filter
                GLPF = exp(-D.^2/(2*D0^2));
                filtered = ifft2(fftshift(FI.*GLPF));
                
            otherwise % "None"
                if(app.cond==true)
                    AdjustBrightnessButtonPushed(app,event);
                    return;
                end
                imshow(app.mod_img,"Parent",app.UIAxes)
                return;
            end
            
            % Convert back to uint8 and handle display
            app.mod_img = uint8(abs(filtered));
            
            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                app.mod_img = cat(3,app.mod_img,app.mod_img,app.mod_img);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
            app.mod_img = cat(3,app.mod_img,app.mod_img,app.mod_img);
        end

        % Selection changed function: HighpassfilterButtonGroup
        function HighpassfilterButtonGroupSelectionChanged(app, event)
            if isempty(app.mod_img)
                return;
            end
            
            selectedButton = app.HighpassfilterButtonGroup.SelectedObject.Text;
            
            % Convert to grayscale if RGB
            if size(app.mod_img, 3) == 3
                img_gray = rgb2gray(app.mod_img);
            else
                img_gray = app.mod_img;
            end
            
            % Get frequency domain representation
            FI = fftshift(fft2(double(img_gray)));
            [m,n] = size(img_gray);
            [X,Y] = meshgrid(1:n,1:m);
            X = X-(n+1)/2; 
            Y = Y-(m+1)/2;
            D = sqrt(X.^2+Y.^2);
            
            % Get cutoff frequency from spinner
            D0 = app.CutoffSpinner.Value;
            
            switch selectedButton

                case "Ideal"
                    IHPF = D > D0;
                    filtered = ifft2(fftshift(FI.*IHPF));
                    
                case "Butterworth"
                    n = 1; % order
                    BHPF = 1 ./ (1.0 + (D0./D).^(2*n));
                    filtered = ifft2(fftshift(FI.*BHPF));
                    
                case "Gaussian"
                    GHPF = 1 - exp(-D.^2/(2*D0^2));
                    filtered = ifft2(fftshift(FI.*GHPF));
                    
                otherwise
                    if(app.cond==true)
                        AdjustBrightnessButtonPushed(app,event);
                        return;
                    end
                    imshow(app.mod_img,"Parent",app.UIAxes)
                    return;
            end
    
            % Convert back to uint8 and handle display
            app.mod_img = uint8(abs(filtered));
            
            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                app.mod_img = cat(3,app.mod_img,app.mod_img,app.mod_img);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
            app.mod_img = cat(3,app.mod_img,app.mod_img,app.mod_img);
        end

        % Selection changed function: ColorspaceconversionButtonGroup
        function ColorspaceconversionButtonGroupSelectionChanged(app, event)
            if isempty(app.mod_img)
                return;
            end
            
            chosen_space = app.ColorspaceconversionButtonGroup.SelectedObject.Text;
            if size(app.mod_img, 3) == 1
                return;
            end
            if ~isa(app.mod_img, 'double')
                app.mod_img = im2double(app.mod_img);
            end
            switch app.current_space
                case 'rgb'
                    tempRGB = app.mod_img; % Already in rgb
                case 'HSV'
                    tempRGB = hsv2rgb(app.mod_img);
                case 'lab'
                    tempRGB = lab2rgb(app.mod_img);
                case 'YCbCr'
                    tempRGB = ycbcr2rgb(app.mod_img);
                otherwise
                    return;
            end
        
            % Convert RGB to the target color space
            switch chosen_space
                case 'rgb'
                    app.mod_img = tempRGB; % No conversion needed
                case 'HSV'
                    app.mod_img = rgb2hsv(tempRGB);
                case 'lab'
                    app.mod_img = rgb2lab(tempRGB);
                case 'YCbCr'
                    app.mod_img = rgb2ycbcr(tempRGB);
                otherwise
                    return;
            end
            
            app.current_space = chosen_space;

            if ~isa(app.mod_img, 'uint8')
                app.mod_img = im2uint8(app.mod_img);
            end

            if(app.cond==true)
                AdjustBrightnessButtonPushed(app,event);
                return;
            end
            imshow(app.mod_img,"Parent",app.UIAxes)
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.AutoResizeChildren = 'off';
            app.UIFigure.Color = [0.9451 0.8588 1];
            app.UIFigure.Position = [100 100 1434 747];
            app.UIFigure.Name = 'MATLAB App';
            app.UIFigure.Scrollable = 'on';

            % Create UIAxes
            app.UIAxes = uiaxes(app.UIFigure);
            zlabel(app.UIAxes, 'Z')
            app.UIAxes.XTick = [];
            app.UIAxes.YTick = [];
            app.UIAxes.Box = 'on';
            app.UIAxes.Position = [651 351 528 377];

            % Create uploadphotoButton
            app.uploadphotoButton = uibutton(app.UIFigure, 'push');
            app.uploadphotoButton.ButtonPushedFcn = createCallbackFcn(app, @uploadphotoButtonPushed, true);
            app.uploadphotoButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.uploadphotoButton.FontSize = 18;
            app.uploadphotoButton.FontColor = [1 1 1];
            app.uploadphotoButton.Position = [1217 539 170 55];
            app.uploadphotoButton.Text = 'upload photo';

            % Create HistogramEqualizationButton
            app.HistogramEqualizationButton = uibutton(app.UIFigure, 'push');
            app.HistogramEqualizationButton.ButtonPushedFcn = createCallbackFcn(app, @HistogramEqualizationButtonPushed, true);
            app.HistogramEqualizationButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.HistogramEqualizationButton.FontSize = 14;
            app.HistogramEqualizationButton.FontColor = [1 1 1];
            app.HistogramEqualizationButton.Position = [1176 73 197 85];
            app.HistogramEqualizationButton.Text = 'Histogram Equalization';

            % Create resetButton
            app.resetButton = uibutton(app.UIFigure, 'push');
            app.resetButton.ButtonPushedFcn = createCallbackFcn(app, @resetButtonPushed, true);
            app.resetButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.resetButton.FontSize = 18;
            app.resetButton.FontColor = [1 1 1];
            app.resetButton.Position = [1217 404 171 55];
            app.resetButton.Text = 'reset';

            % Create ColorspaceconversionButtonGroup
            app.ColorspaceconversionButtonGroup = uibuttongroup(app.UIFigure);
            app.ColorspaceconversionButtonGroup.AutoResizeChildren = 'off';
            app.ColorspaceconversionButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @ColorspaceconversionButtonGroupSelectionChanged, true);
            app.ColorspaceconversionButtonGroup.BorderColor = [0.3412 0.2902 0.3882];
            app.ColorspaceconversionButtonGroup.HighlightColor = [0.3412 0.2902 0.3882];
            app.ColorspaceconversionButtonGroup.TitlePosition = 'centertop';
            app.ColorspaceconversionButtonGroup.Title = 'Color space conversion';
            app.ColorspaceconversionButtonGroup.BackgroundColor = [0.7804 0.6706 0.6706];
            app.ColorspaceconversionButtonGroup.Position = [1195 209 157 84];

            % Create rgbButton
            app.rgbButton = uiradiobutton(app.ColorspaceconversionButtonGroup);
            app.rgbButton.Text = 'rgb';
            app.rgbButton.Position = [8 34 58 22];
            app.rgbButton.Value = true;

            % Create labButton
            app.labButton = uiradiobutton(app.ColorspaceconversionButtonGroup);
            app.labButton.Text = 'lab';
            app.labButton.Position = [8 12 65 22];

            % Create YCbCrButton
            app.YCbCrButton = uiradiobutton(app.ColorspaceconversionButtonGroup);
            app.YCbCrButton.Text = 'YCbCr';
            app.YCbCrButton.Position = [74 34 65 22];

            % Create HSVButton
            app.HSVButton = uiradiobutton(app.ColorspaceconversionButtonGroup);
            app.HSVButton.Text = 'HSV';
            app.HSVButton.Position = [74 12 50 22];

            % Create ColorspaceconversionLabel
            app.ColorspaceconversionLabel = uilabel(app.ColorspaceconversionButtonGroup);
            app.ColorspaceconversionLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.ColorspaceconversionLabel.HorizontalAlignment = 'center';
            app.ColorspaceconversionLabel.FontColor = [1 1 1];
            app.ColorspaceconversionLabel.Position = [0 61 156 22];
            app.ColorspaceconversionLabel.Text = 'Color space conversion';

            % Create SpatialFilteringPanel
            app.SpatialFilteringPanel = uipanel(app.UIFigure);
            app.SpatialFilteringPanel.BorderColor = [0.2196 0.149 0.2392];
            app.SpatialFilteringPanel.ForegroundColor = [1 1 1];
            app.SpatialFilteringPanel.HighlightColor = [0.2196 0.149 0.2392];
            app.SpatialFilteringPanel.TitlePosition = 'centertop';
            app.SpatialFilteringPanel.Title = 'Spatial Filtering';
            app.SpatialFilteringPanel.BackgroundColor = [0.7804 0.6706 0.6706];
            app.SpatialFilteringPanel.FontSize = 24;
            app.SpatialFilteringPanel.Position = [44 20 532 316];

            % Create SmoothingfilterButtonGroup
            app.SmoothingfilterButtonGroup = uibuttongroup(app.SpatialFilteringPanel);
            app.SmoothingfilterButtonGroup.AutoResizeChildren = 'off';
            app.SmoothingfilterButtonGroup.BorderColor = [0.2196 0.149 0.2392];
            app.SmoothingfilterButtonGroup.HighlightColor = [0.2196 0.149 0.2392];
            app.SmoothingfilterButtonGroup.Title = 'Smoothing filter';
            app.SmoothingfilterButtonGroup.Position = [44 134 127 126];

            % Create BoxButton
            app.BoxButton = uiradiobutton(app.SmoothingfilterButtonGroup);
            app.BoxButton.Text = 'Box';
            app.BoxButton.Position = [6 70 58 22];
            app.BoxButton.Value = true;

            % Create AverageButton
            app.AverageButton = uiradiobutton(app.SmoothingfilterButtonGroup);
            app.AverageButton.Text = 'Average';
            app.AverageButton.Position = [6 48 66 22];

            % Create MedianButton
            app.MedianButton = uiradiobutton(app.SmoothingfilterButtonGroup);
            app.MedianButton.Text = 'Median';
            app.MedianButton.Position = [6 26 65 22];

            % Create ApplyfilterButton
            app.ApplyfilterButton = uibutton(app.SpatialFilteringPanel, 'push');
            app.ApplyfilterButton.ButtonPushedFcn = createCallbackFcn(app, @ApplyfilterButtonPushed, true);
            app.ApplyfilterButton.BackgroundColor = [0.3412 0.2902 0.3882];
            app.ApplyfilterButton.FontColor = [1 1 1];
            app.ApplyfilterButton.Position = [53 49 110 22];
            app.ApplyfilterButton.Text = 'Apply filter';

            % Create SharpeningfilterButtonGroup
            app.SharpeningfilterButtonGroup = uibuttongroup(app.SpatialFilteringPanel);
            app.SharpeningfilterButtonGroup.AutoResizeChildren = 'off';
            app.SharpeningfilterButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @SharpeningfilterButtonGroupSelectionChanged, true);
            app.SharpeningfilterButtonGroup.BorderColor = [0.2196 0.149 0.2392];
            app.SharpeningfilterButtonGroup.HighlightColor = [0.2196 0.149 0.2392];
            app.SharpeningfilterButtonGroup.TitlePosition = 'centertop';
            app.SharpeningfilterButtonGroup.Title = 'Sharpening filter';
            app.SharpeningfilterButtonGroup.Position = [245 27 227 243];

            % Create Laplacian1stdervativeButton
            app.Laplacian1stdervativeButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.Laplacian1stdervativeButton.Text = 'Laplacian 1st dervative';
            app.Laplacian1stdervativeButton.Position = [13 168 144 22];

            % Create Laplacian2nddervativeButton
            app.Laplacian2nddervativeButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.Laplacian2nddervativeButton.Text = 'Laplacian 2nd dervative';
            app.Laplacian2nddervativeButton.Position = [13 146 148 22];

            % Create BoostedLaplacian1stdervativeButton
            app.BoostedLaplacian1stdervativeButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.BoostedLaplacian1stdervativeButton.Text = 'Boosted Laplacian 1st dervative';
            app.BoostedLaplacian1stdervativeButton.Position = [13 124 193 22];

            % Create BoostedLaplacian2nddervativeButton
            app.BoostedLaplacian2nddervativeButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.BoostedLaplacian2nddervativeButton.Text = 'Boosted Laplacian 2nd dervative';
            app.BoostedLaplacian2nddervativeButton.Position = [13 103 197 22];

            % Create NoneButton
            app.NoneButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.NoneButton.Text = 'None';
            app.NoneButton.Position = [13 189 50 22];
            app.NoneButton.Value = true;

            % Create SobelButton
            app.SobelButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.SobelButton.Text = 'Sobel';
            app.SobelButton.Position = [13 41 52 21];

            % Create BoostedSobelButton
            app.BoostedSobelButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.BoostedSobelButton.Text = 'Boosted Sobel';
            app.BoostedSobelButton.Position = [13 21 100 25];

            % Create PrewittButton
            app.PrewittButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.PrewittButton.Text = 'Prewitt';
            app.PrewittButton.Position = [13 3 58 21];

            % Create HorizontalSobelButton
            app.HorizontalSobelButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.HorizontalSobelButton.Text = 'Horizontal Sobel';
            app.HorizontalSobelButton.Position = [13 82 110 22];

            % Create VerticalSobelButton
            app.VerticalSobelButton = uiradiobutton(app.SharpeningfilterButtonGroup);
            app.VerticalSobelButton.Text = 'Vertical Sobel';
            app.VerticalSobelButton.Position = [13 61 95 22];

            % Create SmoothingfilterLabel
            app.SmoothingfilterLabel = uilabel(app.SpatialFilteringPanel);
            app.SmoothingfilterLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.SmoothingfilterLabel.HorizontalAlignment = 'center';
            app.SmoothingfilterLabel.FontColor = [1 1 1];
            app.SmoothingfilterLabel.Position = [44 238 127 22];
            app.SmoothingfilterLabel.Text = 'Smoothing filter';

            % Create SharpeningfilterLabel
            app.SharpeningfilterLabel = uilabel(app.SpatialFilteringPanel);
            app.SharpeningfilterLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.SharpeningfilterLabel.HorizontalAlignment = 'center';
            app.SharpeningfilterLabel.FontColor = [1 1 1];
            app.SharpeningfilterLabel.Position = [245 248 227 22];
            app.SharpeningfilterLabel.Text = 'Sharpening filter';

            % Create Label
            app.Label = uilabel(app.SpatialFilteringPanel);
            app.Label.BackgroundColor = [0.3412 0.2902 0.3882];
            app.Label.FontColor = [1 1 1];
            app.Label.Position = [207 49 10 216];
            app.Label.Text = '';

            % Create Label_2
            app.Label_2 = uilabel(app.SpatialFilteringPanel);
            app.Label_2.BackgroundColor = [0.7804 0.6706 0.6706];
            app.Label_2.FontColor = [1 1 1];
            app.Label_2.Position = [212 49 10 217];
            app.Label_2.Text = '';

            % Create FilterSizeDropDownLabel
            app.FilterSizeDropDownLabel = uilabel(app.SpatialFilteringPanel);
            app.FilterSizeDropDownLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.FilterSizeDropDownLabel.HorizontalAlignment = 'center';
            app.FilterSizeDropDownLabel.FontColor = [1 1 1];
            app.FilterSizeDropDownLabel.Position = [10 99 81 22];
            app.FilterSizeDropDownLabel.Text = 'Filter Size';

            % Create FilterSizeDropDown
            app.FilterSizeDropDown = uidropdown(app.SpatialFilteringPanel);
            app.FilterSizeDropDown.Items = {'3X3', '5X5', '7X7', '9X9'};
            app.FilterSizeDropDown.Position = [90 99 100 22];
            app.FilterSizeDropDown.Value = '3X3';

            % Create SpatialdomainFilteringLabel
            app.SpatialdomainFilteringLabel = uilabel(app.UIFigure);
            app.SpatialdomainFilteringLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.SpatialdomainFilteringLabel.HorizontalAlignment = 'center';
            app.SpatialdomainFilteringLabel.FontSize = 24;
            app.SpatialdomainFilteringLabel.FontColor = [1 1 1];
            app.SpatialdomainFilteringLabel.Position = [44 301 532 35];
            app.SpatialdomainFilteringLabel.Text = 'Spatial-domain Filtering';

            % Create ImageintensityPanel
            app.ImageintensityPanel = uipanel(app.UIFigure);
            app.ImageintensityPanel.BorderColor = [0.2196 0.149 0.2392];
            app.ImageintensityPanel.ForegroundColor = [1 1 1];
            app.ImageintensityPanel.HighlightColor = [0.2196 0.149 0.2392];
            app.ImageintensityPanel.TitlePosition = 'centertop';
            app.ImageintensityPanel.Title = 'Image intensity';
            app.ImageintensityPanel.BackgroundColor = [0.7804 0.6706 0.6706];
            app.ImageintensityPanel.FontSize = 24;
            app.ImageintensityPanel.Position = [45 366 494 352];

            % Create AdjustBrightnessButton
            app.AdjustBrightnessButton = uibutton(app.ImageintensityPanel, 'push');
            app.AdjustBrightnessButton.ButtonPushedFcn = createCallbackFcn(app, @AdjustBrightnessButtonPushed, true);
            app.AdjustBrightnessButton.BackgroundColor = [0.3412 0.2863 0.3922];
            app.AdjustBrightnessButton.FontColor = [1 1 1];
            app.AdjustBrightnessButton.Position = [180 25 145 29];
            app.AdjustBrightnessButton.Text = 'Adjust Brightness';

            % Create Low_inLabel
            app.Low_inLabel = uilabel(app.ImageintensityPanel);
            app.Low_inLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.Low_inLabel.FontColor = [1 1 1];
            app.Low_inLabel.Position = [25 269 53 22];
            app.Low_inLabel.Text = ' Low_in';

            % Create Low_inSlider
            app.Low_inSlider = uislider(app.ImageintensityPanel);
            app.Low_inSlider.Limits = [0 1];
            app.Low_inSlider.Position = [90 288 276 3];

            % Create High_inLabel
            app.High_inLabel = uilabel(app.ImageintensityPanel);
            app.High_inLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.High_inLabel.FontColor = [1 1 1];
            app.High_inLabel.Position = [25 212 53 22];
            app.High_inLabel.Text = ' High_in';

            % Create High_inSlider
            app.High_inSlider = uislider(app.ImageintensityPanel);
            app.High_inSlider.Limits = [0 1];
            app.High_inSlider.Position = [94 230 272 3];

            % Create Low_outLabel
            app.Low_outLabel = uilabel(app.ImageintensityPanel);
            app.Low_outLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.Low_outLabel.FontColor = [1 1 1];
            app.Low_outLabel.Position = [25 162 54 22];
            app.Low_outLabel.Text = ' Low_out';

            % Create Low_outSlider
            app.Low_outSlider = uislider(app.ImageintensityPanel);
            app.Low_outSlider.Limits = [0 1];
            app.Low_outSlider.Position = [94 170 272 3];

            % Create High_outLabel
            app.High_outLabel = uilabel(app.ImageintensityPanel);
            app.High_outLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.High_outLabel.FontColor = [1 1 1];
            app.High_outLabel.Position = [25 91 56 22];
            app.High_outLabel.Text = ' High_out';

            % Create High_outSlider
            app.High_outSlider = uislider(app.ImageintensityPanel);
            app.High_outSlider.Limits = [0 1];
            app.High_outSlider.Position = [94 110 278 3];

            % Create ImageIntensityLabel
            app.ImageIntensityLabel = uilabel(app.UIFigure);
            app.ImageIntensityLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.ImageIntensityLabel.HorizontalAlignment = 'center';
            app.ImageIntensityLabel.FontSize = 24;
            app.ImageIntensityLabel.FontColor = [1 1 1];
            app.ImageIntensityLabel.Position = [45 682 494 35];
            app.ImageIntensityLabel.Text = 'Image Intensity';

            % Create frequencyfilteringPanel
            app.frequencyfilteringPanel = uipanel(app.UIFigure);
            app.frequencyfilteringPanel.BorderColor = [0.2196 0.149 0.2392];
            app.frequencyfilteringPanel.HighlightColor = [0.2196 0.149 0.2392];
            app.frequencyfilteringPanel.Title = 'frequency filtering';
            app.frequencyfilteringPanel.BackgroundColor = [0.7804 0.6706 0.6706];
            app.frequencyfilteringPanel.FontSize = 24;
            app.frequencyfilteringPanel.Position = [693 45 381 270];

            % Create LowpassfilterButtonGroup
            app.LowpassfilterButtonGroup = uibuttongroup(app.frequencyfilteringPanel);
            app.LowpassfilterButtonGroup.AutoResizeChildren = 'off';
            app.LowpassfilterButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @LowpassfilterButtonGroupSelectionChanged, true);
            app.LowpassfilterButtonGroup.BorderColor = [0.2196 0.149 0.2392];
            app.LowpassfilterButtonGroup.HighlightColor = [0.2196 0.149 0.2392];
            app.LowpassfilterButtonGroup.Title = 'Low-pass filter';
            app.LowpassfilterButtonGroup.Position = [56 32 123 116];

            % Create IdealButton
            app.IdealButton = uiradiobutton(app.LowpassfilterButtonGroup);
            app.IdealButton.Text = 'Ideal';
            app.IdealButton.Position = [11 48 58 22];

            % Create ButterworthButton
            app.ButterworthButton = uiradiobutton(app.LowpassfilterButtonGroup);
            app.ButterworthButton.Text = 'Butterworth';
            app.ButterworthButton.Position = [11 26 83 22];

            % Create GaussianButton
            app.GaussianButton = uiradiobutton(app.LowpassfilterButtonGroup);
            app.GaussianButton.Text = 'Gaussian';
            app.GaussianButton.Position = [11 4 72 22];

            % Create NoneButton_2
            app.NoneButton_2 = uiradiobutton(app.LowpassfilterButtonGroup);
            app.NoneButton_2.Text = 'None';
            app.NoneButton_2.Position = [11 69 58 22];
            app.NoneButton_2.Value = true;

            % Create LowpassfilterLabel
            app.LowpassfilterLabel = uilabel(app.LowpassfilterButtonGroup);
            app.LowpassfilterLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.LowpassfilterLabel.HorizontalAlignment = 'center';
            app.LowpassfilterLabel.FontColor = [1 1 1];
            app.LowpassfilterLabel.Position = [1 93 122 22];
            app.LowpassfilterLabel.Text = 'Low-pass filter';

            % Create HighpassfilterButtonGroup
            app.HighpassfilterButtonGroup = uibuttongroup(app.frequencyfilteringPanel);
            app.HighpassfilterButtonGroup.AutoResizeChildren = 'off';
            app.HighpassfilterButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @HighpassfilterButtonGroupSelectionChanged, true);
            app.HighpassfilterButtonGroup.BorderColor = [0.2196 0.149 0.2392];
            app.HighpassfilterButtonGroup.HighlightColor = [0.2196 0.149 0.2392];
            app.HighpassfilterButtonGroup.Title = 'High-pass filter';
            app.HighpassfilterButtonGroup.Position = [207 32 123 116];

            % Create IdealButton_2
            app.IdealButton_2 = uiradiobutton(app.HighpassfilterButtonGroup);
            app.IdealButton_2.Text = 'Ideal';
            app.IdealButton_2.Position = [11 48 58 22];

            % Create ButterworthButton_2
            app.ButterworthButton_2 = uiradiobutton(app.HighpassfilterButtonGroup);
            app.ButterworthButton_2.Text = 'Butterworth';
            app.ButterworthButton_2.Position = [11 26 83 22];

            % Create GaussianButton_2
            app.GaussianButton_2 = uiradiobutton(app.HighpassfilterButtonGroup);
            app.GaussianButton_2.Text = 'Gaussian';
            app.GaussianButton_2.Position = [11 4 72 22];

            % Create NoneButton_3
            app.NoneButton_3 = uiradiobutton(app.HighpassfilterButtonGroup);
            app.NoneButton_3.Text = 'None';
            app.NoneButton_3.Position = [11 69 58 22];
            app.NoneButton_3.Value = true;

            % Create HighpassfilterLabel
            app.HighpassfilterLabel = uilabel(app.HighpassfilterButtonGroup);
            app.HighpassfilterLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.HighpassfilterLabel.HorizontalAlignment = 'center';
            app.HighpassfilterLabel.FontColor = [1 1 1];
            app.HighpassfilterLabel.Position = [1 93 121 22];
            app.HighpassfilterLabel.Text = 'High-pass filter';

            % Create CutoffLabel
            app.CutoffLabel = uilabel(app.frequencyfilteringPanel);
            app.CutoffLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.CutoffLabel.HorizontalAlignment = 'center';
            app.CutoffLabel.FontColor = [1 1 1];
            app.CutoffLabel.Position = [130 183 64 22];
            app.CutoffLabel.Text = 'Cutoff ';

            % Create CutoffSpinner
            app.CutoffSpinner = uispinner(app.frequencyfilteringPanel);
            app.CutoffSpinner.Step = 5;
            app.CutoffSpinner.Limits = [5 100];
            app.CutoffSpinner.BackgroundColor = [0.9412 0.9412 0.9412];
            app.CutoffSpinner.Position = [194 183 75 22];
            app.CutoffSpinner.Value = 5;

            % Create FrequencydomainFilteringLabel
            app.FrequencydomainFilteringLabel = uilabel(app.UIFigure);
            app.FrequencydomainFilteringLabel.BackgroundColor = [0.3412 0.2902 0.3882];
            app.FrequencydomainFilteringLabel.HorizontalAlignment = 'center';
            app.FrequencydomainFilteringLabel.FontSize = 24;
            app.FrequencydomainFilteringLabel.FontColor = [1 1 1];
            app.FrequencydomainFilteringLabel.Position = [693 280 381 35];
            app.FrequencydomainFilteringLabel.Text = 'Frequency-domain Filtering';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = task_1_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end